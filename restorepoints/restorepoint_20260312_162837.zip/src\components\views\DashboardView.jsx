import React from 'react';
import {
  Calendar as CalIcon,
  Megaphone,
  Repeat,
  ChevronLeft,
  ChevronRight,
  Pin,
  X
} from 'lucide-react';
import SkeletonBlock from '../SkeletonBlock';

const DashboardView = ({
  waReminder,
  sendWhatsAppReminder,
  activePinnedAnnouncement,
  handleOpenPinned,
  handleDismissPinned,
  setView,
  dataReady,
  data,
  unreadAnnouncementsCount,
  handleCalendarNavigate,
  monthLabel,
  monthWeeks,
  myAssignmentsByDate,
  selectedDate,
  setSelectedDate,
  setCalendarDate,
  formatAssignmentLabel,
  formatDatePt,
  dayAssignments,
  renderSkeletonList,
  myAssignmentsCount
}) => {
  const swapCount = (data.assignments || []).filter((a) => a.status === 'troca').length;
  return (
    <div className="p-5 space-y-6 animate-fade-in max-w-lg sm:max-w-xl lg:max-w-3xl mx-auto w-full">
      <section className="bg-navy-900 p-6 rounded-4xl text-white shadow-xl relative overflow-hidden">
        <span className="text-[9px] font-black uppercase tracking-widest opacity-60">
          Visão Geral
        </span>
        <h3 className="text-xl font-black mt-1">Minhas Designações</h3>
        <p className="text-blue-200 text-xs mt-3 opacity-80">
          Organização e colaboração digital para a congregação.
        </p>
      </section>
      {waReminder && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 p-4 rounded-3xl flex items-center justify-between">
          <div>
            <p className="text-xs font-black uppercase text-amber-700">Lembrete WhatsApp</p>
            <p className="text-sm font-bold">Designação em até 24h</p>
            <span className="text-[10px] text-slate-500">
              {waReminder.tipo_designacao} • {formatDatePt(waReminder.date)}
            </span>
          </div>
          <button
            onClick={() => sendWhatsAppReminder(waReminder)}
            className="px-3 py-2 bg-emerald-600 text-white text-[9px] font-black uppercase rounded-2xl"
          >
            Enviar
          </button>
        </div>
      )}
      {activePinnedAnnouncement && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 p-4 rounded-3xl flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Pin size={14} className="text-amber-600" />
              <p className="text-xs font-black uppercase text-amber-700">Anúncio fixado</p>
            </div>
            <p className="text-sm font-bold mt-1 truncate">{activePinnedAnnouncement.title}</p>
            <p className="text-[10px] text-slate-500 mt-1">{activePinnedAnnouncement.message}</p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <button
              onClick={() => handleOpenPinned(activePinnedAnnouncement.id)}
              className="px-3 py-1.5 bg-amber-600 text-white text-[9px] font-black uppercase rounded-2xl"
            >
              Ler
            </button>
            <button
              onClick={() => handleDismissPinned(activePinnedAnnouncement.id)}
              className="touch-target w-8 h-8 bg-white/70 text-slate-500 rounded-2xl"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        <button
          onClick={() => setView('ASSIGNMENTS_MONTH')}
          className="bg-white dark:bg-navy-800 p-5 rounded-3xl shadow-sm text-left active:scale-95 transition-all min-h-[112px]"
        >
          <CalIcon className="text-blue-500 mb-2" size={20} />
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">
            Agenda
          </span>
          {dataReady.assignments ? (
            <p className="text-2xl font-black dark:text-white mt-1">{myAssignmentsCount}</p>
          ) : (
            <SkeletonBlock className="h-7 w-10 mt-2" />
          )}
        </button>
        <button
          onClick={() => setView('SWAP_MARKET')}
          className="bg-white dark:bg-navy-800 p-5 rounded-3xl shadow-sm text-left active:scale-95 transition-all min-h-[112px]"
        >
          <Repeat className="text-orange-500 mb-2" size={20} />
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">
            Mural
          </span>
          {dataReady.assignments ? (
            <p className="text-2xl font-black dark:text-white mt-1">{swapCount}</p>
          ) : (
            <SkeletonBlock className="h-7 w-10 mt-2" />
          )}
        </button>
        <button
          onClick={() => setView('ANNOUNCEMENTS')}
          className="bg-white dark:bg-navy-800 p-5 rounded-3xl shadow-sm text-left active:scale-95 transition-all relative min-h-[112px]"
        >
          <Megaphone className="text-amber-500 mb-2" size={18} />
          <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">
            Anúncios
          </span>
          {dataReady.announcements ? (
            <p className="text-sm font-black dark:text-white mt-1">{data.announcements.length}</p>
          ) : (
            <SkeletonBlock className="h-5 w-8 mt-2" />
          )}
          {unreadAnnouncementsCount > 0 && (
            <span className="absolute top-2 right-2 min-w-[18px] h-[18px] px-1 bg-red-500 text-white text-[9px] font-black rounded-full flex items-center justify-center">
              {unreadAnnouncementsCount}
            </span>
          )}
        </button>
      </div>

      <div className="bg-white dark:bg-navy-800 p-5 rounded-4xl shadow-sm border dark:border-slate-800">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
          <div>
            <h3 className="text-sm font-black uppercase tracking-widest text-slate-400">
              Calendário
            </h3>
            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">
              Designações (verde)
            </p>
          </div>
        </div>
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => handleCalendarNavigate(-1)}
            className="touch-target w-9 h-9 rounded-xl bg-slate-100 dark:bg-navy-900 text-slate-500 flex items-center justify-center"
          >
            <ChevronLeft size={16} />
          </button>
          <span className="text-xs font-bold capitalize text-slate-500 min-w-[140px] text-center">
            {monthLabel}
          </span>
          <button
            onClick={() => handleCalendarNavigate(1)}
            className="touch-target w-9 h-9 rounded-xl bg-slate-100 dark:bg-navy-900 text-slate-500 flex items-center justify-center"
          >
            <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid grid-cols-7 text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2">
          {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom'].map((d) => (
            <div key={d} className="text-center py-1">
              {d}
            </div>
          ))}
        </div>
        <div className="space-y-1">
          {monthWeeks.map((week, wi) => (
            <div key={`w-${wi}`} className="grid grid-cols-7 gap-1">
              {week.map((day, di) => {
                const hasAssignments = myAssignmentsByDate[day.dateStr]?.length > 0;
                const isSelected = selectedDate === day.dateStr;
                const baseBg = hasAssignments
                  ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-200'
                  : 'bg-slate-50 dark:bg-navy-900';
                return (
                  <button
                    key={`d-${wi}-${di}`}
                    onClick={() => {
                      setSelectedDate(day.dateStr);
                      if (!day.inMonth) {
                        setCalendarDate(
                          new Date(day.date.getFullYear(), day.date.getMonth(), 1)
                        );
                      }
                    }}
                    className={`relative h-9 rounded-xl text-xs font-bold ${day.inMonth ? 'text-slate-800 dark:text-slate-100' : 'text-slate-300'} ${baseBg} ${isSelected ? 'ring-2 ring-navy-900 dark:ring-blue-400' : ''}`}
                  >
                    {day.date.getDate()}
                    {hasAssignments && (
                      <span className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-2">
          <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-400">
            Agenda do dia
          </h4>
          <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">
            Designações: {dayAssignments.length}
          </p>
          {!dataReady.assignments ? (
            <div className="space-y-2">{renderSkeletonList(3, 'h-12 w-full')}</div>
          ) : (
            <>
              {dayAssignments.map((a) => (
                <div
                  key={`cal-${a.id}`}
                  className="bg-slate-50 dark:bg-navy-900 p-3 rounded-2xl flex items-center justify-between"
                >
                  <div>
                    <p className="text-xs font-bold">{formatAssignmentLabel(a.tipo_designacao)}</p>
                    <span className="text-[9px] text-slate-400">{formatDatePt(a.date)}</span>
                  </div>
                  <span
                    className={`text-[8px] font-black px-2 py-1 rounded-full uppercase ${a.status === 'confirmado' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}
                  >
                    {a.status}
                  </span>
                </div>
              ))}
              {dayAssignments.length === 0 && (
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                  Nenhuma designação nessa data.
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
