﻿import React from 'react';
import { Database, Upload, Sparkles } from 'lucide-react';

const AdminBackupTab = ({
  handleExportBackup,
  handleImportBackup,
  handleFixMojibake,
  isFixingMojibake
}) => {
  return (
    <div className="space-y-4 animate-fade-in">
      <h3 className="text-xs font-black uppercase text-slate-400 px-1">Backup e Restauração</h3>
      <div className="bg-white dark:bg-navy-800 p-6 rounded-4xl shadow-md space-y-4">
        <button
          onClick={handleExportBackup}
          className="w-full bg-navy-900 text-white font-black py-4 rounded-2xl text-[10px] uppercase tracking-widest flex items-center justify-center gap-2"
        >
          <Database size={14} /> Fazer Backup Completo
        </button>
        <label className="w-full bg-slate-100 dark:bg-navy-900 text-slate-600 dark:text-slate-300 font-black py-4 rounded-2xl text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer">
          <Upload size={14} /> Importar Backup (JSON)
          <input
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => handleImportBackup(e.target.files?.[0])}
          />
        </label>
        <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">
          Isso pode sobrescrever dados existentes.
        </p>
      </div>

      <div className="bg-white dark:bg-navy-800 p-6 rounded-4xl shadow-md space-y-3">
        <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">
          Correção de Acentuação
        </h4>
        <button
          onClick={handleFixMojibake}
          disabled={isFixingMojibake}
          className="w-full bg-emerald-600 text-white font-black py-4 rounded-2xl text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-60"
        >
          <Sparkles size={14} />
          {isFixingMojibake ? 'Corrigindo...' : 'Corrigir Mojibake'}
        </button>
        <p className="text-[10px] text-slate-400 font-bold">
          Ajusta textos com caracteres quebrados (ç, ã). Atua nos dados carregados no app.
        </p>
      </div>
    </div>
  );
};

export default AdminBackupTab;
