import React from 'react';
import UserAvatar from '../UserAvatar';

const SearchView = ({
  searchFilters,
  setSearchFilters,
  data,
  searchResults,
  ASSIGNMENT_TYPES,
  STATUS_TYPES,
  setView,
  formatDatePt,
  getUserDisplayName,
  getFriendlyTime
}) => {
  return (
    <div className="p-5 space-y-4 animate-fade-in max-w-lg sm:max-w-xl lg:max-w-3xl mx-auto w-full">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2 px-1">
        <h2 className="text-xl font-black uppercase tracking-tight">Busca Avançada</h2>
        <button
          onClick={() => setView('DASHBOARD')}
          className="text-[9px] font-black text-slate-400 uppercase tracking-widest"
        >
          FECHAR
        </button>
      </div>
      <div className="bg-white dark:bg-navy-800 p-5 rounded-4xl shadow-sm space-y-3 border dark:border-slate-800">
        <input
          value={searchFilters.text}
          onChange={(e) => setSearchFilters({ ...searchFilters, text: e.target.value })}
          placeholder="Texto, nome, designação..."
          className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm border dark:border-slate-700"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input
            type="date"
            value={searchFilters.dateFrom}
            onChange={(e) => setSearchFilters({ ...searchFilters, dateFrom: e.target.value })}
            className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm border dark:border-slate-700"
          />
          <input
            type="date"
            value={searchFilters.dateTo}
            onChange={(e) => setSearchFilters({ ...searchFilters, dateTo: e.target.value })}
            className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm border dark:border-slate-700"
          />
        </div>
        <select
          value={searchFilters.user}
          onChange={(e) => setSearchFilters({ ...searchFilters, user: e.target.value })}
          className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm border dark:border-slate-700"
        >
          <option value="">Usuário</option>
          {data.users
            .filter((u) => u.approved)
            .map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} {u.surname}
              </option>
            ))}
        </select>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <select
            value={searchFilters.type}
            onChange={(e) => setSearchFilters({ ...searchFilters, type: e.target.value })}
            className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm border dark:border-slate-700"
          >
            <option value="">Tipo</option>
            {ASSIGNMENT_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          <select
            value={searchFilters.status}
            onChange={(e) => setSearchFilters({ ...searchFilters, status: e.target.value })}
            className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm border dark:border-slate-700"
          >
            <option value="">Status</option>
            {STATUS_TYPES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-[9px] font-black uppercase tracking-widest">
          <label className="flex items-center gap-2 bg-slate-50 dark:bg-navy-900 p-2 rounded-xl">
            <input
              type="checkbox"
              checked={searchFilters.includeAssignments}
              onChange={(e) =>
                setSearchFilters({ ...searchFilters, includeAssignments: e.target.checked })
              }
            />
            Designações
          </label>
          <label className="flex items-center gap-2 bg-slate-50 dark:bg-navy-900 p-2 rounded-xl">
            <input
              type="checkbox"
              checked={searchFilters.includeUsers}
              onChange={(e) =>
                setSearchFilters({ ...searchFilters, includeUsers: e.target.checked })
              }
            />
            Usuários
          </label>
          <label className="flex items-center gap-2 bg-slate-50 dark:bg-navy-900 p-2 rounded-xl">
            <input
              type="checkbox"
              checked={searchFilters.includeNotifications}
              onChange={(e) =>
                setSearchFilters({ ...searchFilters, includeNotifications: e.target.checked })
              }
            />
            Avisos
          </label>
        </div>
      </div>

      {searchFilters.includeAssignments && (
        <div className="space-y-2">
          <h3 className="text-xs font-black uppercase text-slate-400 px-1">Designações</h3>
          {searchResults.assignments.map((a) => (
            <div
              key={`s-${a.id}`}
              className="bg-white dark:bg-navy-800 p-4 rounded-3xl shadow-sm border dark:border-slate-800"
            >
              <p className="text-[9px] font-black text-blue-500 uppercase tracking-widest">
                {formatDatePt(a.date)}
              </p>
              <p className="font-bold text-sm dark:text-white">{a.tipo_designacao}</p>
              <div className="flex justify-between items-center mt-2">
                <p className="text-[10px] text-slate-400 font-black uppercase">
                  {getUserDisplayName(data.users.find((u) => u.id === a.usuario_id))}
                </p>
                <span
                  className={`text-[8px] font-black px-2.5 py-1 rounded-full uppercase tracking-tighter ${a.status === 'confirmado' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}
                >
                  {a.status}
                </span>
              </div>
            </div>
          ))}
          {searchResults.assignments.length === 0 && (
            <p className="text-center text-xs text-slate-400 py-4 font-bold uppercase">
              Nenhum resultado.
            </p>
          )}
        </div>
      )}

      {searchFilters.includeUsers && (
        <div className="space-y-2">
          <h3 className="text-xs font-black uppercase text-slate-400 px-1">Usuários</h3>
          {searchResults.users.map((u) => (
            <div
              key={`u-${u.id}`}
              className="bg-white dark:bg-navy-800 p-4 rounded-3xl shadow-sm border dark:border-slate-800 flex items-center gap-3"
            >
              <UserAvatar
                name={u.name}
                surname={u.surname}
                userId={u.id}
                size="sm"
                lastActive={u.last_active}
              />
              <div className="min-w-0">
                <p className="font-bold text-sm dark:text-white">
                  {u.name} {u.surname}
                </p>
                <p className="text-[10px] text-slate-400 font-medium">{u.phone}</p>
              </div>
            </div>
          ))}
          {searchResults.users.length === 0 && (
            <p className="text-center text-xs text-slate-400 py-4 font-bold uppercase">
              Nenhum resultado.
            </p>
          )}
        </div>
      )}

      {searchFilters.includeNotifications && (
        <div className="space-y-2">
          <h3 className="text-xs font-black uppercase text-slate-400 px-1">Avisos</h3>
          {searchResults.notifications.map((n) => (
            <div
              key={`n-${n.id}`}
              className="bg-white dark:bg-navy-800 p-4 rounded-3xl shadow-sm border dark:border-slate-800"
            >
              <p className="text-sm font-semibold dark:text-slate-100">{n.text}</p>
              <span className="text-[8px] text-slate-400 mt-2 block uppercase font-bold tracking-widest">
                {getFriendlyTime(n.created_at)}
              </span>
            </div>
          ))}
          {searchResults.notifications.length === 0 && (
            <p className="text-center text-xs text-slate-400 py-4 font-bold uppercase">
              Nenhum resultado.
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchView;
