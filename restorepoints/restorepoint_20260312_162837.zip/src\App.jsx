import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';

import { Bell, Search, Settings, Eye, X, RefreshCw } from 'lucide-react';
import Toast from './components/Toast';

import ConfirmModal from './components/ConfirmModal';

import AssignmentConflictModal from './components/AssignmentConflictModal';

import CsvResolveModal from './components/CsvResolveModal';

import UserAvatar from './components/UserAvatar';

import BottomNav from './components/BottomNav';

import OfflineBanner from './components/OfflineBanner';

import SkeletonBlock from './components/SkeletonBlock';

import AuthScreen from './components/AuthScreen';

import UserMenuModal from './components/UserMenuModal';

import AccountModal from './components/AccountModal';

import HelpModal from './components/HelpModal';

import AboutModal from './components/AboutModal';

import AlertsView from './features/alerts/AlertsView';
import NotificationsHistoryView from './features/notifications/NotificationsHistoryView';
import DashboardView from './components/views/DashboardView';
import SearchView from './components/views/SearchView';
import AnnouncementsView from './components/views/AnnouncementsView';
import AdminView from './components/views/AdminView';
import SecondaryViews from './components/views/SecondaryViews';


import {

  onAuthStateChanged,

  signInWithEmailAndPassword,

  createUserWithEmailAndPassword,

  signOut,

  updateProfile,

  EmailAuthProvider,

  reauthenticateWithCredential,

  updatePassword,

  sendPasswordResetEmail

} from 'firebase/auth';

import {

  collection,

  getDoc,

  addDoc,

  updateDoc,

  doc,

  setDoc,

  serverTimestamp,

  deleteDoc,

  arrayUnion,

  writeBatch

} from 'firebase/firestore';

import { auth, db, storage } from './services/firebase';

import { createAppApi } from './services/appApi';

import { ADMIN_UIDS, ASSIGNMENT_TYPES, STATUS_TYPES } from './constants/appConstants';

import { formatAssignmentLabel, normalizeAssignmentType } from './utils/assignmentUtils';

import { getInitialCache } from './utils/cacheUtils';
import { formatDatePt, getDateDaysAgo, getFriendlyTime, isPastDate } from './utils/dateUtils';
import { CSV_TEMPLATE, normalizeCsvDate, parseCsv } from './utils/csvUtils';

import { buildIcsContent } from './utils/icsUtils';

import {
  buildWhatsAppLink,
  deriveNameFromEmail,
  fixMojibake,
  getUserDisplayName,
  normalizePersonName,
  stripAccents
} from './utils/textUtils';
import { withRetry } from './utils/asyncUtils';

import { useSoundSettings } from './hooks/useSoundSettings';
import { useHistoryNavigation } from './hooks/useHistoryNavigation';
import { useNetworkStatus } from './hooks/useNetworkStatus';
import { useToasts } from './hooks/useToasts';
import { useCacheSync } from './hooks/useCacheSync';
import { useDismissedPins } from './hooks/useDismissedPins';
import { useSearchFilters } from './hooks/useSearchFilters';
import { useAdminTabs } from './hooks/useAdminTabs';
import { useNotificationsState } from './hooks/useNotificationsState';
import { useReportsAnalytics } from './hooks/useReportsAnalytics';
import { usePinnedAnnouncement } from './hooks/usePinnedAnnouncement';
import { useWhatsAppReminder } from './hooks/useWhatsAppReminder';
import { useCalendarState } from './hooks/useCalendarState';
import { useAnnouncementActions } from './hooks/actions/useAnnouncementActions';
import { useNotificationActions } from './hooks/actions/useNotificationActions';
import { useAppDataLoader } from './hooks/useAppDataLoader';


const ensureAuth = async () => {

  if (!auth.currentUser) throw new Error('not-authenticated');

  return auth.currentUser;

};



const isAdminUid = (uid) => ADMIN_UIDS.includes(uid);



const api = createAppApi({ auth, db, storage, ensureAuth, withRetry });

const App = () => {

  const initialCache = getInitialCache();

  const [user, setUser] = useState(null);

  const [originalAdmin, setOriginalAdmin] = useState(() =>

    JSON.parse(localStorage.getItem('original_admin'))

  );

  const [view, setView] = useState('DASHBOARD');

  const { adminTab, setAdminTab } = useAdminTabs();
  const [loginState, setLoginState] = useState('SIGNIN');
  const [authReady, setAuthReady] = useState(false);

  const isOnline = useNetworkStatus();
  const [confirmState, setConfirmState] = useState({ open: false, loading: false });


  const confirm = useCallback((opts = {}) => {
    return new Promise((resolve) => {
      setConfirmState({ open: true, loading: false, ...opts, resolve });
    });
  }, []);

  const closeConfirm = useCallback(() => {
    if (confirmState?.resolve) confirmState.resolve(false);
    setConfirmState({ open: false, loading: false });
  }, [confirmState]);

  const acceptConfirm = useCallback(() => {
    if (!confirmState?.resolve) return;
    setConfirmState((prev) => ({ ...prev, loading: true }));
    confirmState.resolve(true);
    setConfirmState({ open: false, loading: false });
  }, [confirmState]);

  const actionLocks = useRef(new Set());

  const [alertTab, setAlertTab] = useState('NOTIFICATIONS');

  const [isDark, setIsDark] = useState(() => localStorage.getItem('theme') === 'dark');

  const [isLoading, setIsLoading] = useState(false);

  const { toasts, addToast, removeToast } = useToasts();
  const [dataError, setDataError] = useState(null);

  const [updateAvailable, setUpdateAvailable] = useState(false);

  const [availableVersion, setAvailableVersion] = useState('');

  const [currentVersion, setCurrentVersion] = useState('');

  const [updateInfoOpen, setUpdateInfoOpen] = useState(false);

  const [updateProgress, setUpdateProgress] = useState(0);

  const [isUpdatingApp, setIsUpdatingApp] = useState(false);
  const [isRefreshingAll, setIsRefreshingAll] = useState(false);
  const [isImportingAssignments, setIsImportingAssignments] = useState(false);
  const [isFixingMojibake, setIsFixingMojibake] = useState(false);
  const [filters, setFilters] = useState({

    name: '',

    date: '',

    type: '',

    status: '',

    hasFiltered: false

  });

  const [isHelpOpen, setIsHelpOpen] = useState(false);

  const [isAboutOpen, setIsAboutOpen] = useState(false);

  const [selectedAdminUser, setSelectedAdminUser] = useState(null);

  const [reassigningId, setReassigningId] = useState(null);

  const [isChangingPass, setIsChangingPass] = useState(false);

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const { dismissedPinned, setDismissedPinned } = useDismissedPins(user?.id);
  const [openSwapLogId, setOpenSwapLogId] = useState(null);

  const [assignForm, setAssignForm] = useState({ date: '', userId: '', type: '' });

  const [assignmentConflict, setAssignmentConflict] = useState(null);

  const [csvResolveState, setCsvResolveState] = useState({
    open: false,
    rows: [],
    baseAssignments: []
  });
  const isImpersonating =
    !!originalAdmin && !!auth.currentUser?.uid && !!user?.id && auth.currentUser.uid !== user.id;
  const isRealAdminUser = useMemo(
    () => user && (user.isAdmin || isAdminUid(user.id)) && !originalAdmin,
    [user, originalAdmin]
  );
  const isRegisteringRef = useRef(false);
  useHistoryNavigation({ user, view, setView });

  const {
    soundEnabled,
    toggleSoundNotifications,
    dndEnabled,

    setDndEnabled,

    dndFrom,

    setDndFrom,

    dndTo,

    setDndTo

  } = useSoundSettings({ userId: user?.id, addToast });



  useEffect(() => {

    const v = window.__APP_VERSION__ || '';

    if (!v) return;

    setCurrentVersion(v);

    const key = 'app_version';

    const prev = localStorage.getItem(key);

    if (prev && prev !== v) {

      addToast(`App atualizado para ${v}.`, 'success');

    }

    if (!prev) {

      localStorage.setItem(key, v);

    } else if (prev !== v) {

      localStorage.setItem(key, v);

    }

  }, [addToast]);



  const runExclusive = useCallback(async (key, fn) => {

    if (actionLocks.current.has(key)) return false;

    actionLocks.current.add(key);

    try {

      await fn();

      return true;

    } finally {

      actionLocks.current.delete(key);

    }

  }, []);



  

  const guardAuth = useCallback(async () => {
    try {
      await ensureAuth();
      return true;
    } catch (e) {
      console.error(e);
      addToast('Faça login para continuar.', 'warn');
      return false;
    }
  }, [addToast]);

  const {
    data,
    setData,
    dataReady,
    setDataReady,
    handleRefreshData,
    safeLoadSections,
    loadForView
  } = useAppDataLoader({
    initialData: initialCache.data,
    initialReady: initialCache.ready,
    db,
    withRetry,
    getDateDaysAgo,
    isImpersonating,
    user,
    isRealAdminUser,
    authReady,
    guardAuth,
    addToast
  });

  useCacheSync(data);

  const assignmentsByDate = useMemo(() => {

    const map = {};

    data.assignments.forEach((a) => {

      if (!a?.date) return;

      if (!map[a.date]) map[a.date] = [];

      map[a.date].push(a);

    });

    return map;

  }, [data.assignments]);



  const assignmentCountsByMonthUser = useMemo(() => {

    const map = {};

    data.assignments.forEach((a) => {

      if (!a?.date || !a?.usuario_id) return;

      const month = a.date.slice(0, 7);

      if (!map[month]) map[month] = {};

      map[month][a.usuario_id] = (map[month][a.usuario_id] || 0) + 1;

    });

    return map;

  }, [data.assignments]);



  const getUserAssignmentsOnDate = useCallback(

    (userId, dateStr) => {

      if (!userId || !dateStr) return [];

      return (assignmentsByDate[dateStr] || []).filter((a) => a.usuario_id === userId);

    },

    [assignmentsByDate]

  );



  const selectedUserAssignments = useMemo(() => {

    return getUserAssignmentsOnDate(assignForm.userId, assignForm.date);

  }, [assignForm.userId, assignForm.date, getUserAssignmentsOnDate]);



  const selectedMonthKey = assignForm.date ? assignForm.date.slice(0, 7) : '';

  const monthCountsForSelected = useMemo(

    () => assignmentCountsByMonthUser[selectedMonthKey] || {},

    [assignmentCountsByMonthUser, selectedMonthKey]

  );



  const freeUsersForSelectedDate = useMemo(() => {

    if (!assignForm.date) return [];

    const assigned = new Set((assignmentsByDate[assignForm.date] || []).map((a) => a.usuario_id));

    return data.users

      .filter((u) => u.approved && !assigned.has(u.id))

      .sort((a, b) => {

        const ca = monthCountsForSelected[a.id] || 0;

        const cb = monthCountsForSelected[b.id] || 0;

        if (ca !== cb) return ca - cb;

        return getUserDisplayName(a).localeCompare(getUserDisplayName(b));

      });

  }, [assignForm.date, assignmentsByDate, data.users, monthCountsForSelected]);




  const conflictDate = assignmentConflict?.date || '';
  const conflictMonthCounts = useMemo(() => {
    if (!conflictDate) return {};
    const key = conflictDate.slice(0, 7);
    return assignmentCountsByMonthUser[key] || {};
  }, [assignmentCountsByMonthUser, conflictDate]);

  const freeUsersForConflictDate = useMemo(() => {
    if (!conflictDate) return [];
    const assigned = new Set((assignmentsByDate[conflictDate] || []).map((a) => a.usuario_id));
    return data.users.filter((u) => u.approved && !assigned.has(u.id));
  }, [assignmentsByDate, conflictDate, data.users]);

  const resetAssignForm = useCallback(() => {

    setAssignForm({ date: '', userId: '', type: '' });

  }, []);



    const createAssignmentRecord = useCallback(
    async ({ date, userId, type, status = 'pendente', location = '' }) => {
      if (!(await guardAuth())) return null;
      const payload = {
        date,
        usuario_id: userId,
        tipo_designacao: type,
        status,
        location: location || '',
        created_at: serverTimestamp(),
        created_by: user?.id || ''
      };
      const refDoc = await addDoc(collection(db, 'assignments'), payload);
      setData((prev) => ({
        ...prev,
        assignments: [{ id: refDoc.id, ...payload }, ...(prev.assignments || [])]
      }));
      return refDoc;
    },
    [addDoc, collection, db, guardAuth, setData, user?.id]
  );

  const handleCreateAssignment = useCallback(
    async (e) => {
      e.preventDefault();
      if (!assignForm.date || !assignForm.userId || !assignForm.type) return;
      const conflicts = getUserAssignmentsOnDate(assignForm.userId, assignForm.date);
      if (conflicts.length > 0) {
        const userRef = data.users.find((u) => u.id === assignForm.userId);
        setAssignmentConflict({
          open: true,
          date: assignForm.date,
          userId: assignForm.userId,
          userName: getUserDisplayName(userRef),
          type: assignForm.type,
          conflicts
        });
        return;
      }
      try {
        await createAssignmentRecord({
          date: assignForm.date,
          userId: assignForm.userId,
          type: assignForm.type
        });
        addToast('Designação criada.', 'success');
        resetAssignForm();
      } catch (e2) {
        addToast('Erro ao criar designação.', 'error');
      }
    },
    [
      addToast,
      assignForm.date,
      assignForm.type,
      assignForm.userId,
      createAssignmentRecord,
      data.users,
      getUserAssignmentsOnDate,
      resetAssignForm
    ]
  );

  const handleAssignAnyway = useCallback(async () => {
    if (!assignmentConflict?.date || !assignmentConflict?.userId || !assignmentConflict?.type) {
      setAssignmentConflict(null);
      return;
    }
    try {
      await createAssignmentRecord({
        date: assignmentConflict.date,
        userId: assignmentConflict.userId,
        type: assignmentConflict.type
      });
      addToast('Designação criada.', 'success');
      resetAssignForm();
    } catch (e) {
      addToast('Erro ao criar designação.', 'error');
    } finally {
      setAssignmentConflict(null);
    }
  }, [addToast, assignmentConflict, createAssignmentRecord, resetAssignForm]);

  const handlePickAlternativeUser = useCallback(
    async (userId) => {
      if (!assignmentConflict?.date || !assignmentConflict?.type || !userId) {
        setAssignmentConflict(null);
        return;
      }
      try {
        await createAssignmentRecord({
          date: assignmentConflict.date,
          userId,
          type: assignmentConflict.type
        });
        addToast('Designação criada.', 'success');
        resetAssignForm();
      } catch (e) {
        addToast('Erro ao criar designação.', 'error');
      } finally {
        setAssignmentConflict(null);
      }
    },
    [addToast, assignmentConflict, createAssignmentRecord, resetAssignForm]
  );

  const handlePickNextAvailable = useCallback(() => {
    if (!assignForm.date || freeUsersForSelectedDate.length === 0) return;
    setAssignForm((prev) => ({ ...prev, userId: freeUsersForSelectedDate[0].id }));
  }, [assignForm.date, freeUsersForSelectedDate]);

  const handleDeleteAssignment = useCallback(
    async (id) => {
      const confirmed = await confirm({
        title: 'Excluir designação',
        message: 'Deseja excluir esta designação?',
        confirmText: 'Excluir'
      });
      if (!confirmed) return;
      try {
        await deleteDoc(doc(db, 'assignments', id));
        setData((prev) => ({
          ...prev,
          assignments: (prev.assignments || []).filter((a) => a.id !== id)
        }));
        addToast('Designação excluída.', 'success');
      } catch (e) {
        addToast('Erro ao excluir designação.', 'error');
      }
    },
    [addToast, confirm, db, deleteDoc, doc, setData]
  );

  const handleReassign = useCallback(
    async (assignmentId, newUserId) => {
      if (!assignmentId || !newUserId) return;
      try {
        await updateDoc(doc(db, 'assignments', assignmentId), { usuario_id: newUserId });
        setData((prev) => ({
          ...prev,
          assignments: (prev.assignments || []).map((a) =>
            a.id === assignmentId ? { ...a, usuario_id: newUserId } : a
          )
        }));
        addToast('Designação atualizada.', 'success');
        setReassigningId(null);
      } catch (e) {
        addToast('Erro ao atualizar designação.', 'error');
      }
    },
    [addToast, db, doc, setData, updateDoc]
  );

  const commitAssignmentsImport = useCallback(

    async (assignments, perUserCounts) => {

      if (assignments.length === 0) return;

      const chunks = [];

      for (let i = 0; i < assignments.length; i += 450) {

        chunks.push(assignments.slice(i, i + 450));

      }

      for (const chunk of chunks) {

        const batch = writeBatch(db);

        chunk.forEach((payload) => {

          const refDoc = doc(collection(db, 'assignments'));

          const dataPayload = { ...payload };

          if (!dataPayload.location) delete dataPayload.location;

          batch.set(refDoc, dataPayload);

        });

        await batch.commit();

      }



      const notifEntries = Array.from(perUserCounts.entries()).map(([uid, count]) => ({

        targetUserId: uid,

        count

      }));

      const notifChunks = [];

      for (let i = 0; i < notifEntries.length; i += 450) {

        notifChunks.push(notifEntries.slice(i, i + 450));

      }

      for (const chunk of notifChunks) {

        const batch = writeBatch(db);

        chunk.forEach(({ targetUserId, count }) => {

          const refDoc = doc(collection(db, 'notifications'));

          const text =

            count === 1

              ? 'Você recebeu 1 nova designação.'

              : `Você recebeu ${count} novas designações.`;

          batch.set(refDoc, {

            text,

            authorId: user.id,

            targetUserId,

            created_at: serverTimestamp(),

            type: 'assignment_import',

            targetView: 'ASSIGNMENTS_MONTH',

            read_by: []

          });

        });

        await batch.commit();

      }

    },

    [user?.id]

  );




  const handleAccept = useCallback(
    async (assignmentId) => {
      try {
        await updateDoc(doc(db, 'assignments', assignmentId), { status: 'confirmado' });
        setData((prev) => ({
          ...prev,
          assignments: (prev.assignments || []).map((a) =>
            a.id === assignmentId ? { ...a, status: 'confirmado' } : a
          )
        }));
        addToast('Designação confirmada.', 'success');
      } catch (e) {
        addToast('Erro ao confirmar designação.', 'error');
      }
    },
    [addToast, db, doc, setData, updateDoc]
  );

  const logSwapAction = useCallback(
    async (assignmentId, action) => {
      try {
        await addDoc(collection(db, 'swap_logs'), {
          assignmentId,
          action,
          actorId: user?.id || '',
          createdAt: serverTimestamp()
        });
      } catch (e) {
        // noop
      }
    },
    [addDoc, collection, db, user?.id]
  );

  const handleSwapRequest = useCallback(
    async (assignment) => {
      if (!assignment?.id) return;
      try {
        await updateDoc(doc(db, 'assignments', assignment.id), { status: 'troca' });
        setData((prev) => ({
          ...prev,
          assignments: (prev.assignments || []).map((a) =>
            a.id === assignment.id ? { ...a, status: 'troca' } : a
          )
        }));
        await logSwapAction(assignment.id, 'solicitar_troca');
        addToast('Troca solicitada.', 'success');
      } catch (e) {
        addToast('Erro ao solicitar troca.', 'error');
      }
    },
    [addToast, db, doc, logSwapAction, setData, updateDoc]
  );

  const handleCancelSwap = useCallback(
    async (assignment) => {
      if (!assignment?.id) return;
      try {
        await updateDoc(doc(db, 'assignments', assignment.id), { status: 'pendente' });
        setData((prev) => ({
          ...prev,
          assignments: (prev.assignments || []).map((a) =>
            a.id === assignment.id ? { ...a, status: 'pendente' } : a
          )
        }));
        await logSwapAction(assignment.id, 'cancelar_troca');
        addToast('Troca cancelada.', 'success');
      } catch (e) {
        addToast('Erro ao cancelar troca.', 'error');
      }
    },
    [addToast, db, doc, logSwapAction, setData, updateDoc]
  );

  const handleAcceptSwap = useCallback(
    async (assignmentId) => {
      if (!assignmentId) return;
      try {
        await updateDoc(doc(db, 'assignments', assignmentId), {
          usuario_id: user.id,
          status: 'pendente'
        });
        setData((prev) => ({
          ...prev,
          assignments: (prev.assignments || []).map((a) =>
            a.id === assignmentId ? { ...a, usuario_id: user.id, status: 'pendente' } : a
          )
        }));
        await logSwapAction(assignmentId, 'aceitar_troca');
        addToast('Troca aceita.', 'success');
      } catch (e) {
        addToast('Erro ao aceitar troca.', 'error');
      }
    },
    [addToast, db, doc, logSwapAction, setData, updateDoc, user?.id]
  );

  const handleUpdateApproval = useCallback(
    async (uid, approved) => {
      try {
        await updateDoc(doc(db, 'users', uid), { approved: !!approved });
        setData((prev) => ({
          ...prev,
          users: (prev.users || []).map((u) => (u.id === uid ? { ...u, approved } : u))
        }));
        addToast('Aprovação atualizada.', 'success');
      } catch (e) {
        addToast('Erro ao atualizar aprovação.', 'error');
      }
    },
    [addToast, db, doc, setData, updateDoc]
  );

  const handleApproveAll = useCallback(async () => {
    try {
      const batch = writeBatch(db);
      (data.users || []).filter((u) => !u.approved).forEach((u) => {
        batch.update(doc(db, 'users', u.id), { approved: true });
      });
      await batch.commit();
      setData((prev) => ({
        ...prev,
        users: (prev.users || []).map((u) => ({ ...u, approved: true }))
      }));
      addToast('Todos aprovados.', 'success');
    } catch (e) {
      addToast('Erro ao aprovar todos.', 'error');
    }
  }, [addToast, data.users, db, doc, setData, writeBatch]);

  const handleApproveByDomain = useCallback(async () => {
    const domain = prompt('Digite o domínio (ex: exemplo.com)');
    if (!domain) return;
    try {
      const batch = writeBatch(db);
      (data.users || [])
        .filter((u) => (u.email || '').toLowerCase().endsWith(`@${domain.toLowerCase()}`))
        .forEach((u) => {
          batch.update(doc(db, 'users', u.id), { approved: true });
        });
      await batch.commit();
      setData((prev) => ({
        ...prev,
        users: (prev.users || []).map((u) =>
          (u.email || '').toLowerCase().endsWith(`@${domain.toLowerCase()}`)
            ? { ...u, approved: true }
            : u
        )
      }));
      addToast('Aprovação em massa concluída.', 'success');
    } catch (e) {
      addToast('Erro ao aprovar por domínio.', 'error');
    }
  }, [addToast, data.users, db, doc, setData, writeBatch]);

  const handleImpersonate = useCallback(
    (target) => {
      if (!target || !user) return;
      setOriginalAdmin(user);
      localStorage.setItem('original_admin', JSON.stringify(user));
      setUser(target);
      setView('DASHBOARD');
    },
    [user]
  );

  const stopImpersonating = useCallback(() => {
    const authUid = auth.currentUser?.uid;
    const adminUser = data.users.find((u) => u.id === authUid) || originalAdmin;
    if (adminUser) setUser(adminUser);
    setOriginalAdmin(null);
    localStorage.removeItem('original_admin');
    setView('DASHBOARD');
  }, [auth.currentUser?.uid, data.users, originalAdmin]);

  const handleToggleAdminRole = useCallback(
    async (uid, isAdmin) => {
      try {
        await updateDoc(doc(db, 'users', uid), { isAdmin: !!isAdmin });
        setData((prev) => ({
          ...prev,
          users: (prev.users || []).map((u) => (u.id === uid ? { ...u, isAdmin } : u))
        }));
        addToast('Permissão atualizada.', 'success');
      } catch (e) {
        addToast('Erro ao atualizar permissão.', 'error');
      }
    },
    [addToast, db, doc, setData, updateDoc]
  );

  const handleDeleteUser = useCallback(
    async (uid) => {
      const confirmed = await confirm({
        title: 'Excluir usuário',
        message: 'Deseja excluir este usuário?',
        confirmText: 'Excluir'
      });
      if (!confirmed) return;
      try {
        await deleteDoc(doc(db, 'users', uid));
        setData((prev) => ({
          ...prev,
          users: (prev.users || []).filter((u) => u.id !== uid)
        }));
        addToast('Usuário excluído.', 'success');
      } catch (e) {
        addToast('Erro ao excluir usuário.', 'error');
      }
    },
    [addToast, confirm, db, deleteDoc, doc, setData]
  );

  const handleAdminUpdateUserName = useCallback(
    async (uid, name, surname) => {
      try {
        await updateDoc(doc(db, 'users', uid), { name, surname });
        setData((prev) => ({
          ...prev,
          users: (prev.users || []).map((u) => (u.id === uid ? { ...u, name, surname } : u))
        }));
        addToast('Usuário atualizado.', 'success');
      } catch (e) {
        addToast('Erro ao atualizar usuário.', 'error');
      }
    },
    [addToast, db, doc, setData, updateDoc]
  );

  const handleSendBroadcast = useCallback(
    async (e) => {
      e.preventDefault();
      const form = e.target;
      const msg = String(form.msg.value || '').trim();
      if (!msg) return;
      try {
        const batch = writeBatch(db);
        (data.users || []).filter((u) => u.approved).forEach((u) => {
          const refDoc = doc(collection(db, 'notifications'));
          batch.set(refDoc, {
            text: msg,
            authorId: user.id,
            targetUserId: u.id,
            created_at: serverTimestamp(),
            type: 'broadcast',
            targetView: 'ALERTS',
            read_by: []
          });
        });
        await batch.commit();
        addToast('Comunicado enviado.', 'success');
        form.reset();
      } catch (e2) {
        addToast('Erro ao enviar comunicado.', 'error');
      }
    },
    [addToast, collection, db, doc, serverTimestamp, user?.id, data.users, writeBatch]
  );

  const downloadCsv = useCallback((filename, rows) => {
    const content = rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }, []);

  useEffect(() => {

    const onUpdate = (event) => {

      const nextVersion = event?.detail?.version || '';

      if (nextVersion) setAvailableVersion(nextVersion);

      setUpdateAvailable(true);

    };

    const onActivated = () => {

      if (updateAvailable || isUpdatingApp) {

        window.location.reload();

      }

    };

    window.addEventListener('sw-update', onUpdate);

    window.addEventListener('sw-activated', onActivated);

    return () => {

      window.removeEventListener('sw-update', onUpdate);

      window.removeEventListener('sw-activated', onActivated);

    };

  }, [updateAvailable, isUpdatingApp]);



  useEffect(() => {

    if (!updateInfoOpen || !isUpdatingApp) return undefined;

    setUpdateProgress(10);

    const tick = () => {

      setUpdateProgress((prev) => {

        if (prev >= 90) return prev;

        return Math.min(90, prev + Math.max(2, Math.round(Math.random() * 6)));

      });

    };

    const id = window.setInterval(tick, 450);

    return () => window.clearInterval(id);

  }, [updateInfoOpen, isUpdatingApp]);



  const renderSkeletonList = useCallback((count = 3, className = 'h-16 w-full') => {
    return Array.from({ length: count }).map((_, idx) => (
      <SkeletonBlock key={`sk-${idx}`} className={className} />
    ));
  }, []);

  useEffect(() => {

    let alive = true;

    const unsub = onAuthStateChanged(auth, async (u) => {

      if (!alive) return;

      if (!u) {

        setUser(null);

        setAuthReady(true);

        return;

      }

      setAuthReady(true);

      if (isRegisteringRef.current) return;

      try {

        const refDoc = doc(db, 'users', u.uid);

        const snap = await getDoc(refDoc);

        if (!snap.exists()) {

          const display = u.displayName || '';

          const derived = display

            ? {

                name: display.split(' ')[0] || 'Usuário',

                surname: display.split(' ').slice(1).join(' ')

              }

            : deriveNameFromEmail(u.email || '');

          const name = derived.name || 'Usuário';

          const surname = derived.surname || '';

          const payload = {

            name,

            surname,

            phone: '',

            email: u.email || '',

            approved: isAdminUid(u.uid),

            isAdmin: isAdminUid(u.uid),

            created_at: serverTimestamp(),

            last_active: serverTimestamp()

          };

          await setDoc(refDoc, payload, { merge: true });

          setUser({ id: u.uid, ...payload });

          if (!payload.isAdmin && !isRegisteringRef.current) {

            await signOut(auth);

            addToast('Aguardando aprovação do Admin.', 'info');

          }

          return;

        }

        const dataUser = snap.data() || {};

        const merged = {

          id: u.uid,

          ...dataUser,

          email: u.email || dataUser.email || '',

          isAdmin: isAdminUid(u.uid) || dataUser.isAdmin

        };

        if (!merged.name || !merged.surname) {

          const derived = u.displayName

            ? {

                name: u.displayName.split(' ')[0] || '',

                surname: u.displayName.split(' ').slice(1).join(' ')

              }

            : deriveNameFromEmail(merged.email || '');

          const nextName = merged.name || derived.name;

          const nextSurname = merged.surname || derived.surname;

          if (nextName || nextSurname) {

            await setDoc(

              doc(db, 'users', u.uid),

              { name: nextName, surname: nextSurname },

              { merge: true }

            );

            merged.name = nextName;

            merged.surname = nextSurname;

          }

        }



        if (isAdminUid(u.uid)) {

          if (merged.approved !== true || merged.isAdmin !== true) {

            await setDoc(

              doc(db, 'users', u.uid),

              { approved: true, isAdmin: true },

              { merge: true }

            );

            merged.approved = true;

            merged.isAdmin = true;

          }

        }



        if (!merged.isAdmin && merged.approved === false && !isRegisteringRef.current) {

          await signOut(auth);

          addToast('Aguardando aprovação do Admin.', 'info');

          return;

        }

        setUser(merged);

      } catch (e) {

        console.error(e);

        addToast('Erro ao carregar perfil.', 'error');

      }

    });

    return () => {

      alive = false;

      unsub();

    };

  }, [addToast]);




  const handleForceUpdate = useCallback(async ({ hard } = {}) => {
    if (!('serviceWorker' in navigator)) return;
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      if (!reg) return;
      await reg.update();
      if (hard && reg.waiting) {
        reg.waiting.postMessage({ type: 'SKIP_WAITING' });
      }
    } catch (err) {
      console.warn('SW update failed', err);
    }
  }, []);

  const handleManualUpdate = useCallback(async () => {
    try {
      await handleForceUpdate({ hard: true });
    } finally {
      window.location.reload();
    }
  }, [handleForceUpdate]);

  const handleLogin = useCallback(
    async (e) => {
      e.preventDefault();
      if (isLoading) return;
      const form = e.target;
      const email = String(form.email?.value || '').trim();
      const password = String(form.password?.value || '');
      if (!email || !password) return;
      setIsLoading(true);
      try {
        await signInWithEmailAndPassword(auth, email, password);
        setLoginState('SIGNIN');
      } catch (err) {
        console.error(err);
        addToast('E-mail ou senha inválidos.', 'error');
      } finally {
        setIsLoading(false);
      }
    },
    [addToast, isLoading]
  );

  const handlePasswordReset = useCallback(
    async (e) => {
      e.preventDefault();
      if (isLoading) return;
      const form = e.target;
      const email = String(form.email?.value || '').trim();
      if (!email) return;
      setIsLoading(true);
      try {
        await sendPasswordResetEmail(auth, email);
        addToast('Link enviado para seu e-mail.', 'success');
        setLoginState('SIGNIN');
      } catch (err) {
        console.error(err);
        addToast('Erro ao enviar link.', 'error');
      } finally {
        setIsLoading(false);
      }
    },
    [addToast, isLoading]
  );

  const handleRegisterSelf = useCallback(
    async (e) => {
      e.preventDefault();
      if (isLoading) return;
      const form = e.target;
      const name = String(form.name?.value || '').trim();
      const surname = String(form.surname?.value || '').trim();
      const phone = String(form.phone?.value || '').trim();
      const email = String(form.email?.value || '').trim();
      const password = String(form.password?.value || '');
      const password2 = String(form.password2?.value || '');
      if (!name || !surname || !phone || !email || !password) return;
      if (password !== password2) {
        addToast('As senhas não conferem.', 'error');
        return;
      }
      setIsLoading(true);
      isRegisteringRef.current = true;
      try {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        const displayName = `${name} ${surname}`.trim();
        if (auth.currentUser) {
          await updateProfile(auth.currentUser, { displayName });
        }
        const payload = {
          name,
          surname,
          phone,
          email,
          approved: isAdminUid(cred.user.uid),
          isAdmin: isAdminUid(cred.user.uid),
          created_at: serverTimestamp(),
          last_active: serverTimestamp()
        };
        await setDoc(doc(db, 'users', cred.user.uid), payload, { merge: true });
        if (!payload.isAdmin) {
          await signOut(auth);
          addToast('Cadastro enviado. Aguarde aprovação do Admin.', 'info');
          setLoginState('SIGNIN');
        } else {
          setUser({ id: cred.user.uid, ...payload });
        }
      } catch (err) {
        console.error(err);
        addToast('Erro ao criar cadastro.', 'error');
      } finally {
        isRegisteringRef.current = false;
        setIsLoading(false);
      }
    },
    [addToast, isLoading]
  );

  const handleLogout = useCallback(async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error(err);
    } finally {
      setOriginalAdmin(null);
      localStorage.removeItem('original_admin');
      setUser(null);
    }
  }, []);

  const handleChangePassword = useCallback(
    async (e) => {
      e.preventDefault();
      const form = e.target;
      const current = String(form.current?.value || '');
      const n1 = String(form.n1?.value || '');
      const n2 = String(form.n2?.value || '');
      if (!current || !n1 || !n2) return;
      if (n1 !== n2) {
        addToast('As senhas não conferem.', 'error');
        return;
      }
      try {
        const currentUser = auth.currentUser;
        if (!currentUser?.email) throw new Error('missing-user');
        const cred = EmailAuthProvider.credential(currentUser.email, current);
        await reauthenticateWithCredential(currentUser, cred);
        await updatePassword(currentUser, n1);
        addToast('Senha atualizada.', 'success');
        form.reset();
        setIsChangingPass(false);
      } catch (err) {
        console.error(err);
        addToast('Erro ao atualizar senha.', 'error');
      }
    },
    [addToast]
  );

  const handleChangeDisplayName = useCallback(
    async (e) => {
      e.preventDefault();
      const form = e.target;
      const fullName = String(form.fullName?.value || '').trim();
      if (!fullName || !user?.id) return;
      const parts = fullName.split(/\s+/).filter(Boolean);
      const name = parts.shift() || '';
      const surname = parts.join(' ');
      try {
        if (auth.currentUser) {
          await updateProfile(auth.currentUser, { displayName: fullName });
        }
        await updateDoc(doc(db, 'users', user.id), { name, surname });
        setUser((prev) => (prev ? { ...prev, name, surname } : prev));
        addToast('Nome atualizado.', 'success');
      } catch (err) {
        console.error(err);
        addToast('Erro ao atualizar nome.', 'error');
      }
    },
    [addToast, user?.id]
  );

  const handleUpdatePreferences = useCallback(
    async (e) => {
      e.preventDefault();
      if (!user?.id) return;
      const form = e.target;
      const payload = {
        preferredLanguage: form.language?.value || 'pt-BR',
        hidePhone: !!form.hidePhone?.checked,
        availabilityFrom: form.availFrom?.value || '08:00',
        availabilityTo: form.availTo?.value || '20:00',
        availabilityNote: form.availNote?.value || ''
      };
      try {
        await updateDoc(doc(db, 'users', user.id), payload);
        setUser((prev) => (prev ? { ...prev, ...payload } : prev));
        addToast('Prefer?ncias atualizadas.', 'success');
      } catch (err) {
        console.error(err);
        addToast('Erro ao atualizar prefer?ncias.', 'error');
      }
    },
    [addToast, user?.id]
  );

  const handleDownloadAssignmentsTemplate = useCallback(() => {
    const blob = new Blob([CSV_TEMPLATE], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'template_designacoes.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    addToast('Template CSV baixado.', 'success');
  }, [addToast]);

  const normalizeStatus = (value) => {
    const raw = stripAccents(String(value || '').toLowerCase());
    if (raw.startsWith('conf')) return 'confirmado';
    if (raw.startsWith('pend')) return 'pendente';
    if (raw.startsWith('troca')) return 'troca';
    return 'pendente';
  };

  const buildAssignmentPayload = useCallback(
    (date, userId, type, status) => ({
      date,
      usuario_id: userId,
      tipo_designacao: type,
      status: status || 'pendente',
      created_at: serverTimestamp(),
      created_by: user?.id || ''
    }),
    [user?.id]
  );

  const handleImportAssignmentsFile = useCallback(
    async (file) => {
      if (!file) return;
      if (isImportingAssignments) return;
      if (!(await guardAuth())) return;
      setIsImportingAssignments(true);
      try {
        const text = await file.text();
        const { rows } = parseCsv(text);
        if (!rows.length) {
          addToast('Arquivo CSV vazio.', 'warn');
          return;
        }
        const usersIndex = data.users.map((u) => ({
          id: u.id,
          label: getUserDisplayName(u),
          norm: normalizePersonName(getUserDisplayName(u))
        }));
        const resolved = [];
        const unresolved = [];
        rows.forEach((row, idx) => {
          const name = row.nome || row.name || row.usuario || row.user || '';
          const task = row.tarefa || row.tipo || row.designacao || row['designação'] || '';
          const date = normalizeCsvDate(row.data || row.date || row.dia || '');
          const status = normalizeStatus(row.status || row.situacao || row['situação']);
          const type = normalizeAssignmentType(task);
          if (!date || !type) return;
          const normName = normalizePersonName(name);
          const candidates = usersIndex.filter(
            (u) =>
              u.norm && (u.norm == normName || u.norm.includes(normName) || normName.includes(u.norm))
          );
          if (candidates.length === 1) {
            resolved.push(buildAssignmentPayload(date, candidates[0].id, type, status));
            return;
          }
          unresolved.push({
            line: idx + 2,
            name,
            candidates,
            selectedId: '',
            payload: { date, type, status }
          });
        });
        if (unresolved.length > 0) {
          const rowsWithHandlers = unresolved.map((row, idx) => ({
            ...row,
            onSelect: (value) =>
              setCsvResolveState((prev) => ({
                ...prev,
                rows: prev.rows.map((r, i) => (i === idx ? { ...r, selectedId: value } : r))
              }))
          }));
          setCsvResolveState({ open: true, rows: rowsWithHandlers, baseAssignments: resolved });
          addToast('Resolva os nomes pendentes.', 'warn');
          return;
        }
        const perUserCounts = new Map();
        resolved.forEach((a) => {
          perUserCounts.set(a.usuario_id, (perUserCounts.get(a.usuario_id) || 0) + 1);
        });
        await commitAssignmentsImport(resolved, perUserCounts);
        addToast('Importação concluída.', 'success');
      } catch (err) {
        console.error(err);
        addToast('Erro ao importar CSV.', 'error');
      } finally {
        setIsImportingAssignments(false);
      }
    },
    [addToast, buildAssignmentPayload, commitAssignmentsImport, data.users, guardAuth, isImportingAssignments]
  );

  const handleConfirmCsvResolve = useCallback(async () => {
    const rows = csvResolveState.rows || [];
    if (!rows.length) {
      setCsvResolveState({ open: false, rows: [], baseAssignments: [] });
      return;
    }
    const pending = rows.find((r) => !r.selectedId);
    if (pending) {
      addToast('Selecione usu?rios para todas as linhas.', 'warn');
      return;
    }
    const assignments = [...(csvResolveState.baseAssignments || [])];
    rows.forEach((r) => {
      assignments.push(buildAssignmentPayload(r.payload.date, r.selectedId, r.payload.type, r.payload.status));
    });
    const perUserCounts = new Map();
    assignments.forEach((a) => {
      perUserCounts.set(a.usuario_id, (perUserCounts.get(a.usuario_id) || 0) + 1);
    });
    try {
      await commitAssignmentsImport(assignments, perUserCounts);
      addToast('Importação concluída.', 'success');
      setCsvResolveState({ open: false, rows: [], baseAssignments: [] });
    } catch (err) {
      console.error(err);
      addToast('Erro ao importar CSV.', 'error');
    }
  }, [addToast, buildAssignmentPayload, commitAssignmentsImport, csvResolveState]);

  const handleExportBackup = useCallback(async () => {
    if (!(await guardAuth())) return;
    try {
      const payload = await api.exportData();
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup_minhas_designacoes_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      addToast('Backup exportado.', 'success');
    } catch (err) {
      console.error(err);
      addToast('Erro ao exportar backup.', 'error');
    }
  }, [addToast, api, guardAuth]);

  const handleImportBackup = useCallback(
    async (file) => {
      if (!file) return;
      if (!(await guardAuth())) return;
      const confirmed = await confirm({
        title: 'Importar backup',
        message: 'Isso pode sobrescrever dados existentes. Deseja continuar?',
        confirmText: 'Importar'
      });
      if (!confirmed) return;
      try {
        const text = await file.text();
        const payload = JSON.parse(text);
        await api.importData(payload);
        await handleRefreshData({ silent: true });
        addToast('Backup importado.', 'success');
      } catch (err) {
        console.error(err);
        addToast('Erro ao importar backup.', 'error');
      }
    },
    [addToast, api, confirm, guardAuth, handleRefreshData]
  );


  const downloadIcs = useCallback(
    (assignment) => {
      if (!assignment?.date) return;
      const title = formatAssignmentLabel(assignment.tipo_designacao || 'Designação');
      const description = `Designação em ${formatDatePt(assignment.date)}`;
      const content = buildIcsContent({ title, dateStr: assignment.date, description });
      const blob = new Blob([content], { type: 'text/calendar;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `designacao_${assignment.date}.ics`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    },
    [formatAssignmentLabel, formatDatePt]
  );

  useEffect(() => {

    if (!user || !authReady) return;

    setDataError(null);

    handleRefreshData({ silent: true });

  }, [user, authReady, handleRefreshData, isImpersonating]);





  useEffect(() => {

    if (!authReady || originalAdmin) return;

    const authUid = auth.currentUser?.uid;

    if (!authUid) return;

    const latest = data.users.find((u) => u.id === authUid);

    if (!latest) return;

    if (

      !user ||

      user.id !== authUid ||

      user.isAdmin !== latest.isAdmin ||

      user.approved !== latest.approved ||

      user.name !== latest.name ||

      user.surname !== latest.surname

    ) {

      setUser(latest);

    }

  }, [data.users, user, originalAdmin, authReady]);



  useEffect(() => {

    if (!originalAdmin?.id) return;

    const latest = data.users.find((u) => u.id === originalAdmin.id);

    if (!latest) return;

    const hasChanged =

      latest.isAdmin !== originalAdmin.isAdmin ||

      latest.approved !== originalAdmin.approved ||

      latest.name !== originalAdmin.name ||

      latest.surname !== originalAdmin.surname;

    if (hasChanged) {

      setOriginalAdmin(latest);

      localStorage.setItem('original_admin', JSON.stringify(latest));

    }

  }, [data.users, originalAdmin]);



  useEffect(() => {

    document.documentElement.classList.toggle('dark', isDark);

    localStorage.setItem('theme', isDark ? 'dark' : 'light');

  }, [isDark]);

  const {
    selectedDate,
    setSelectedDate,
    setCalendarDate,
    monthWeeks,
    monthLabel,
    myAssignmentsByDate,
    dayAssignments,
    myAssignmentsCount,
    handleCalendarNavigate
  } = useCalendarState({
    assignments: data.assignments,
    user,
    formatAssignmentLabel,
    formatDatePt
  });

  const { waReminder } = useWhatsAppReminder({
    assignments: data.assignments,
    user,
    isPastDate
  });
  const sendWhatsAppReminder = useCallback(
    (assignment) => {
      if (!assignment || !user) return;
      const message = `Lembrete: sua designação "${assignment.tipo_designacao}" é em ${formatDatePt(assignment.date)}.`;
      const link = buildWhatsAppLink(user.phone || '', message);
      window.open(link, '_blank', 'noopener');
      if (assignment.id) {
        localStorage.setItem(`wa_reminder_${user.id}_${assignment.id}`, 'sent');
      }
      addToast('Lembrete enviado.', 'success');
    },
    [user, addToast, formatDatePt]
  );


  useEffect(() => {

    if (!user || !authReady) return;

    const tomorrowKey = (a) => `internal_reminder_${user.id}_${a.id}`;

    const now = new Date();

    data.assignments

      .filter((a) => a.usuario_id === user.id && a.status !== 'confirmado')

      .forEach(async (a) => {

        const targetDate = new Date(`${a.date}T12:00:00`);

        const diffDays = Math.floor((targetDate - now) / (1000 * 60 * 60 * 24));

        if (diffDays === 1) {

          const key = tomorrowKey(a);

          if (localStorage.getItem(key)) return;

          try {

            await addDoc(collection(db, 'notifications'), {

              text: `Lembrete: sua designação "${a.tipo_designacao}" é amanhã (${formatDatePt(a.date)}).`,

              authorId: user.id,

              created_at: serverTimestamp(),

              type: 'reminder',

              targetView: 'ASSIGNMENTS_MONTH',

              read_by: []

            });

            localStorage.setItem(key, 'sent');

          } catch (e) {

            // noop

          }

        }

      });

  }, [data.assignments, user, authReady]);



  const refreshDashboardCounters = useCallback(async () => {

    // Disabled to reduce Firestore reads on free tier.

    return;

  }, []);

  const {
    notificationsForUser,
    unreadNotificationsCount,
    unreadAnnouncementsCount,
    totalAlertsCount
  } = useNotificationsState({
    notifications: data.notifications,
    announcements: data.announcements,
    user
  });

  const { searchFilters, setSearchFilters, searchResults } = useSearchFilters({
    assignments: data.assignments,
    users: data.users,
    notifications: notificationsForUser,
    formatDatePt
  });


  const filteredAssignments = useMemo(() => {
    if (!filters.hasFiltered) return [];
    return data.assignments.filter((a) => {
      if (filters.name && a.usuario_id != filters.name) return false;
      if (filters.date && a.date != filters.date) return false;
      if (filters.status && a.status != filters.status) return false;
      if (filters.type && a.tipo_designacao != filters.type) return false;
      return true;
    });
  }, [data.assignments, filters]);

  const { activePinnedAnnouncement } = usePinnedAnnouncement({
    announcements: data.announcements,
    dismissedPinned
  });

  
  const resolveNotificationTarget = useCallback((n) => {
    if (!n) return 'ALERTS';
    if (n.targetView) {
      const allowedTargets = new Set([
        'ALERTS',
        'ANNOUNCEMENTS',
        'ASSIGNMENTS_MONTH',
        'SWAP_MARKET',
        'DASHBOARD',
        'SEARCH',
        'NOTIFICATIONS_LIST'
      ]);
      if (allowedTargets.has(n.targetView)) return n.targetView;
    }
    if (n.type === 'announcement') return 'ANNOUNCEMENTS';
    if (n.type === 'reminder' || n.type === 'assignment_import') return 'ASSIGNMENTS_MONTH';
    return 'ALERTS';
  }, []);

  const {
    handleCreateAnnouncement,
    handleDeleteAnnouncement,
    handleMarkAnnouncementRead,
    handleDismissPinned,
    handleOpenPinned,
    handleClearReadAnnouncements
  } = useAnnouncementActions({
    api,
    db,
    user,
    addToast,
    confirm,
    runExclusive,
    guardAuth,
    setDismissedPinned,
    setView,
    data,
    collection,
    addDoc,
    serverTimestamp,
    deleteDoc,
    doc,
    updateDoc,
    arrayUnion
  });

  const { handleClearNotifications, handleOpenNotification } = useNotificationActions({
    db,
    user,
    addToast,
    confirm,
    runExclusive,
    guardAuth,
    setUser,
    setData,
    data,
    resolveNotificationTarget,
    setView,
    doc,
    updateDoc,
    arrayUnion,
    serverTimestamp
  });


  const swapLogsByAssignment = useMemo(() => {

    const map = {};

    (data.swapLogs || []).forEach((l) => {

      if (!l.assignmentId) return;

      if (!map[l.assignmentId]) map[l.assignmentId] = [];

      map[l.assignmentId].push(l);

    });

    Object.values(map).forEach((arr) =>

      arr.sort((a, b) => {

        const ta = a.createdAt?.toMillis?.() || a.createdAt || 0;

        const tb = b.createdAt?.toMillis?.() || b.createdAt || 0;

        return tb - ta;

      })

    );

    return map;

  }, [data.swapLogs]);

  const { assignmentReport } = useReportsAnalytics({
    assignments: data.assignments,
    formatAssignmentLabel
  });


  const adminUserId = originalAdmin?.id || auth.currentUser?.uid || user?.id;
  const adminUser =
    data.users.find((u) => u.id === adminUserId) ||
    (adminUserId === user?.id ? user : originalAdmin);
  const isAdmin = adminUser && (adminUser.isAdmin || isAdminUid(adminUser.id));
  const isRealAdmin = isAdmin && !originalAdmin;

  const handleFixMojibake = useCallback(async () => {
    if (isFixingMojibake) return;
    if (!isAdmin) {
      addToast('Apenas administradores podem executar a limpeza.', 'warn');
      return;
    }
    const confirmed = await confirm({
      title: 'Corrigir acentuação',
      message:
        'Essa rotina corrige textos com caracteres quebrados (mojibake). Ela atualiza os documentos carregados no app.',
      confirmText: 'Corrigir'
    });
    if (!confirmed) return;
    setIsFixingMojibake(true);
    try {
      const updatesByCollection = new Map();
      const queueUpdate = (collectionName, id, changes) => {
        if (!updatesByCollection.has(collectionName)) {
          updatesByCollection.set(collectionName, new Map());
        }
        updatesByCollection.get(collectionName).set(id, changes);
      };
      const collect = (collectionName, items, fields) => {
        (items || []).forEach((item) => {
          if (!item?.id) return;
          const changes = {};
          fields.forEach((field) => {
            if (typeof item[field] !== 'string') return;
            const fixed = fixMojibake(item[field]);
            if (fixed !== item[field]) {
              changes[field] = fixed;
            }
          });
          if (Object.keys(changes).length > 0) {
            queueUpdate(collectionName, item.id, changes);
          }
        });
      };

      collect('users', data.users, ['name', 'surname', 'displayName']);
      collect('assignments', data.assignments, ['tipo_designacao', 'status', 'location']);
      collect('notifications', data.notifications, ['text']);
      collect('announcements', data.announcements, ['title', 'message']);

      const entries = [];
      updatesByCollection.forEach((map, collectionName) => {
        map.forEach((changes, id) => {
          entries.push({ collectionName, id, changes });
        });
      });

      if (entries.length === 0) {
        addToast('Nenhum texto com problema encontrado.', 'info');
        return;
      }

      for (let i = 0; i < entries.length; i += 400) {
        const batch = writeBatch(db);
        entries.slice(i, i + 400).forEach((entry) => {
          batch.update(doc(db, entry.collectionName, entry.id), entry.changes);
        });
        await batch.commit();
      }

      const applyUpdates = (list, map) => {
        if (!map) return list;
        return (list || []).map((item) => {
          const changes = map.get(item.id);
          return changes ? { ...item, ...changes } : item;
        });
      };

      setData((prev) => ({
        ...prev,
        users: applyUpdates(prev.users, updatesByCollection.get('users')),
        assignments: applyUpdates(prev.assignments, updatesByCollection.get('assignments')),
        notifications: applyUpdates(prev.notifications, updatesByCollection.get('notifications')),
        announcements: applyUpdates(prev.announcements, updatesByCollection.get('announcements'))
      }));

      addToast(`Correção concluída. ${entries.length} item(s) atualizados.`, 'success');
    } catch (err) {
      console.error(err);
      addToast('Erro ao corrigir acentuação.', 'error');
    } finally {
      setIsFixingMojibake(false);
    }
  }, [
    addToast,
    confirm,
    data,
    db,
    doc,
    fixMojibake,
    isAdmin,
    isFixingMojibake,
    writeBatch
  ]);


  const dashboardProps = {
    waReminder,
    sendWhatsAppReminder,
    activePinnedAnnouncement,
    handleOpenPinned,
    handleDismissPinned,
    setView,
    dataReady,
    data,
    unreadAnnouncementsCount,
    handleCalendarNavigate,
    monthLabel,
    monthWeeks,
    myAssignmentsByDate,
    selectedDate,
    setSelectedDate,
    setCalendarDate,
    formatAssignmentLabel,
    formatDatePt,
    dayAssignments,
    renderSkeletonList,
    myAssignmentsCount
  };

  const handleRefreshAll = useCallback(async () => {
    if (isRefreshingAll) return;
    setIsRefreshingAll(true);
    try {
      await handleRefreshData();
      await refreshDashboardCounters();
    } finally {
      setIsRefreshingAll(false);
    }
  }, [handleRefreshData, isRefreshingAll, refreshDashboardCounters]);

  const adminViewProps = {
    adminTab,
    setAdminTab,
    data,
    assignForm,
    setAssignForm,
    handleCreateAssignment,
    getUserAssignmentsOnDate,
    formatAssignmentLabel,
    ASSIGNMENT_TYPES,
    selectedUserAssignments,
    handlePickNextAvailable,
    freeUsersForSelectedDate,
    formatDatePt,
    monthCountsForSelected,
    getUserDisplayName,
    handleDownloadAssignmentsTemplate,
    isImportingAssignments,
    handleImportAssignmentsFile,
    reassigningId,
    setReassigningId,
    handleDeleteAssignment,
    handleReassign,
    filters,
    setFilters,
    STATUS_TYPES,
    filteredAssignments,
    handleUpdateApproval,
    handleApproveAll,
    handleApproveByDomain,
    user,
    isAdminUid,
    handleImpersonate,
    selectedAdminUser,
    setSelectedAdminUser,
    handleToggleAdminRole,
    handleDeleteUser,
    handleAdminUpdateUserName,
    handleSendBroadcast,
    assignmentReport,
    downloadCsv,
    handleExportBackup,
    handleImportBackup,
    handleFixMojibake,
    isFixingMojibake
  };

  const secondaryViewProps = {
    view,
    data,
    dataReady,
    user,
    getFriendlyTime,
    renderSkeletonList,
    formatDatePt,
    formatAssignmentLabel,
    isPastDate,
    handleAccept,
    handleSwapRequest,
    handleCancelSwap,
    downloadIcs,
    openSwapLogId,
    setOpenSwapLogId,
    swapLogsByAssignment,
    getUserDisplayName,
    handleAcceptSwap
  };
if (!user) {

    return (

      <AuthScreen

        toasts={toasts}

        onCloseToast={removeToast}
        loginState={loginState}

        setLoginState={setLoginState}

        isLoading={isLoading}

        onLogin={handleLogin}

        onResetPassword={handlePasswordReset}

        onRegister={handleRegisterSelf}

      />

    );

  }



  return (

    <div className="flex flex-col h-full bg-slate-50 dark:bg-navy-950">

      {toasts.map((t) => (

        <Toast

          key={t.id}

          msg={t.msg}

          type={t.type}

          onClose={() => removeToast(t.id)}
        />

      ))}

      <OfflineBanner isOnline={isOnline} />

      {updateAvailable && (

        <div className="bg-blue-600 text-white text-[10px] font-black uppercase tracking-widest py-2 px-4 flex items-center justify-between relative">

          <span>{isUpdatingApp ? 'Atualizando app...' : 'Nova versão disponível'}</span>

          <button

            onClick={async () => {

              setUpdateInfoOpen(true);

              setIsUpdatingApp(true);

              setUpdateProgress(15);

              await handleForceUpdate({ hard: updateAvailable });

              setUpdateProgress(100);

              setTimeout(() => setUpdateInfoOpen(false), 900);

              setTimeout(() => setIsUpdatingApp(false), 1200);

            }}

            disabled={isUpdatingApp}

            className="bg-white text-blue-700 px-3 py-1 rounded-xl text-[9px] font-black uppercase"

          >

            {isUpdatingApp ? 'Aguarde...' : 'Atualizar'}

          </button>

          {updateInfoOpen && (

            <div className="absolute right-3 top-12 z-[220] w-64 rounded-2xl bg-white text-slate-800 shadow-2xl border border-slate-100 p-4 animate-fade-in">

              <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">

                Atualização

              </p>

              <div className="mt-2 space-y-1 text-[10px] font-bold">

                <p>

                  Versão atual: <span className="font-black">{currentVersion || '—'}</span>

                </p>

                <p>

                  Próxima versão:{' '}

                  <span className="font-black">

                    {availableVersion || (currentVersion ? `${currentVersion}+` : '—')}

                  </span>

                </p>

              </div>

              <div className="mt-3 h-2 w-full rounded-full bg-slate-100 overflow-hidden">

                <div

                  className="h-full bg-blue-600 transition-all"

                  style={{ width: `${Math.max(8, updateProgress)}%` }}

                />

              </div>

              <p className="mt-2 text-[9px] uppercase tracking-widest text-slate-400 font-bold">

                {isUpdatingApp ? 'Aplicando atualização...' : 'Pronto para atualizar'}

              </p>

            </div>

          )}

        </div>

      )}

      {dataError && (

        <div className="bg-red-50 text-red-700 text-[10px] font-black uppercase tracking-widest text-center py-2">

          {dataError}

        </div>

      )}

      <ConfirmModal state={confirmState} onCancel={closeConfirm} onConfirm={acceptConfirm} />

      <AssignmentConflictModal

        state={assignmentConflict}

        onClose={() => setAssignmentConflict(null)}

        onAssignAnyway={handleAssignAnyway}

        onPickUser={handlePickAlternativeUser}

        freeUsers={freeUsersForConflictDate}

        monthCounts={conflictMonthCounts}

        formatDatePt={formatDatePt}

        formatAssignmentLabel={formatAssignmentLabel}

        getUserDisplayName={getUserDisplayName}

      />

      <CsvResolveModal

        state={csvResolveState}

        onCancel={() => setCsvResolveState({ open: false, rows: [], baseAssignments: [] })}

        onConfirm={handleConfirmCsvResolve}

      />

      {originalAdmin && user.id !== originalAdmin.id && (

        <div className="bg-orange-600 text-white py-2 px-4 text-[9px] font-black uppercase tracking-widest flex justify-between items-center z-[200] shadow-xl sticky top-0 animate-fade-in">

          <span className="flex items-center gap-2">

            <Eye size={12} /> Visualizando como: {user.name}

          </span>

          <button

            onClick={stopImpersonating}

            className="bg-white text-orange-600 px-3 py-1 rounded-lg"

          >

            SAIR MODO

          </button>

        </div>

      )}



      <header className="px-6 py-4 bg-white dark:bg-navy-900 border-b dark:border-slate-800 flex justify-between items-center z-50 sticky top-0 shadow-sm glass">
        <div className="flex items-center gap-3">
          <button onClick={() => setIsUserMenuOpen(true)} className="touch-target">
            <UserAvatar
              name={user.name}
              surname={user.surname}

              userId={user.id}

              size="md"

              lastActive={Date.now()}

            />

          </button>

          <div className="min-w-0">

            <h2 className="text-sm font-black dark:text-white leading-tight truncate">

              Olá, {getUserDisplayName(user)}

            </h2>

            <span className="text-[9px] text-emerald-500 font-bold uppercase tracking-widest">

              Acesso Ativo

            </span>

          </div>

        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setView('SEARCH')}
            className="touch-target w-9 h-9 bg-navy-900 text-white rounded-2xl flex items-center justify-center shadow-sm"
          >
            <Search size={16} />
          </button>
          <button
            onClick={handleManualUpdate}
            className={`touch-target w-9 h-9 rounded-2xl flex items-center justify-center shadow-sm border ${
              updateAvailable ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white dark:bg-navy-800 text-slate-500 border-slate-200 dark:border-slate-700'
            }`}
            title="Atualizar app"
          >
            <RefreshCw size={16} className={isUpdatingApp ? 'animate-spin' : ''} />
          </button>
          <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-navy-800 px-2 h-9 rounded-2xl">
            <button
              onClick={() => setView('ALERTS')}
              className="touch-target w-8 h-8 rounded-xl flex items-center justify-center text-slate-500 relative"
            >
              <Bell size={16} />

              {totalAlertsCount > 0 && (

                <div className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"></div>

              )}

            </button>

            {isRealAdmin && (

              <button

                onClick={() => setView('ADMIN')}

                className={`touch-target w-8 h-8 rounded-xl flex items-center justify-center ${view === 'ADMIN' ? 'bg-navy-900 text-white' : 'bg-white/70 dark:bg-navy-700 text-navy-600'}`}

              >

                <Settings size={16} />

              </button>

            )}

          </div>

        </div>

      </header>



      <main className="flex-1 overflow-y-auto no-scrollbar pb-40">

        <UserMenuModal

          open={isUserMenuOpen}

          user={user}

          displayName={getUserDisplayName(user)}

          currentVersion={currentVersion}

          isDark={isDark}

          isRefreshing={isRefreshingAll}

          onToggleDark={() => setIsDark(!isDark)}

          onRefresh={handleRefreshAll}

          onOpenAccount={() => {

            setIsChangingPass(true);

            setIsUserMenuOpen(false);

          }}

          onOpenHelp={() => {

            setIsHelpOpen(true);

            setIsUserMenuOpen(false);

          }}

          onOpenAbout={() => {
            setIsAboutOpen(true);
            setIsUserMenuOpen(false);
          }}
          onLogout={handleLogout}
          onClose={() => setIsUserMenuOpen(false)}
        />
        <AccountModal
          open={isChangingPass}

          user={user}

          displayName={getUserDisplayName(user)}

          onClose={() => setIsChangingPass(false)}

          onChangePassword={handleChangePassword}

          onChangeDisplayName={handleChangeDisplayName}

          onUpdatePreferences={handleUpdatePreferences}

          soundEnabled={soundEnabled}

          toggleSoundNotifications={toggleSoundNotifications}

          dndEnabled={dndEnabled}

          setDndEnabled={setDndEnabled}

          dndFrom={dndFrom}

          setDndFrom={setDndFrom}

          dndTo={dndTo}

          setDndTo={setDndTo}

        />

        <HelpModal open={isHelpOpen} onClose={() => setIsHelpOpen(false)} />

        <AboutModal
          open={isAboutOpen}
          onClose={() => setIsAboutOpen(false)}
          currentVersion={currentVersion}
        />


        {view === 'DASHBOARD' && (
          <DashboardView {...dashboardProps} />
        )}

        {view === 'SEARCH' && (
          <SearchView
            searchFilters={searchFilters}
            setSearchFilters={setSearchFilters}
            data={data}
            searchResults={searchResults}
            ASSIGNMENT_TYPES={ASSIGNMENT_TYPES}
            STATUS_TYPES={STATUS_TYPES}
            setView={setView}
            formatDatePt={formatDatePt}
            getUserDisplayName={getUserDisplayName}
            getFriendlyTime={getFriendlyTime}
          />
        )}

        {view === 'ANNOUNCEMENTS' && (
          <AnnouncementsView
            isRealAdmin={isRealAdmin}
            handleClearReadAnnouncements={handleClearReadAnnouncements}
            setView={setView}
            handleCreateAnnouncement={handleCreateAnnouncement}
            dataReady={dataReady}
            data={data}
            getFriendlyTime={getFriendlyTime}
            handleDeleteAnnouncement={handleDeleteAnnouncement}
            handleMarkAnnouncementRead={handleMarkAnnouncementRead}
            user={user}
            renderSkeletonList={renderSkeletonList}
          />
        )}

        {view === 'ALERTS' && (

          <AlertsView

            user={user}

            notificationsForUser={notificationsForUser}

            data={data}

            alertTab={alertTab}

            setAlertTab={setAlertTab}

            handleOpenNotification={handleOpenNotification}

            handleMarkAnnouncementRead={handleMarkAnnouncementRead}

            handleClearNotifications={handleClearNotifications}

            getFriendlyTime={getFriendlyTime}

            unreadNotificationsCount={unreadNotificationsCount}

            unreadAnnouncementsCount={unreadAnnouncementsCount}

            onClose={() => setView('DASHBOARD')}

          />

        )}



        {view === 'NOTIFICATIONS_LIST' && (

          <NotificationsHistoryView

            dataReady={dataReady}

            notificationsForUser={notificationsForUser}

            renderSkeletonList={renderSkeletonList}

            getFriendlyTime={getFriendlyTime}

            totalApprovedUsers={totalApprovedUsers}

            handleClearNotifications={handleClearNotifications}

            setView={setView}

            updateDoc={updateDoc}

            doc={doc}

            db={db}

            arrayUnion={arrayUnion}

            resolveNotificationTarget={resolveNotificationTarget}

            user={user}

          />

        )}



        {view === 'ADMIN' && isRealAdmin && (
          <AdminView {...adminViewProps} />
        )}
        <SecondaryViews {...secondaryViewProps} />
      </main>



      <BottomNav

        view={view}

        unreadAnnouncementsCount={unreadAnnouncementsCount}

        onNavigate={(next) => {
          setView(next);

        }}

      />

    </div>

  );

};



export default App;























































































































