﻿import React from 'react';
import { X } from 'lucide-react';

const CsvResolveModal = ({ state, onCancel, onConfirm }) => {
  if (!state?.open) return null;
  const rows = state.rows || [];
  return (
    <div
      className="fixed inset-0 z-[260] bg-black/40 flex items-center justify-center p-4 animate-fade-in"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-lg bg-white dark:bg-navy-900 card-surface rounded-4xl shadow-2xl p-6 space-y-4 max-h-[85vh] overflow-y-auto no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-sm font-black uppercase tracking-widest">Resolver nomes do CSV</h3>
            <p className="text-xs text-slate-500 mt-2">
              Alguns nomes não bateram exatamente. Escolha o usuário correto.
            </p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="Fechar"
            className="touch-target w-8 h-8 rounded-full bg-slate-100 dark:bg-navy-800 flex items-center justify-center"
          >
            <X size={14} />
          </button>
        </div>
        <div className="space-y-3">
          {rows.map((r, idx) => (
            <div
              key={`${r.line}_${idx}`}
              className="p-3 rounded-3xl bg-slate-50 dark:bg-navy-800 border dark:border-slate-700"
            >
              <div className="flex items-center justify-between">
                <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">
                  Linha {r.line}
                </p>
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">
                  {r.name || 'Sem nome'}
                </span>
              </div>
              <div className="mt-2">
                <select
                  value={r.selectedId || ''}
                  onChange={(e) => r.onSelect(e.target.value)}
                  className="w-full p-2 bg-white dark:bg-navy-900 rounded-xl text-xs font-bold border dark:border-slate-700"
                >
                  <option value="">Selecione o usuário</option>
                  {(r.candidates || []).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
          {rows.length === 0 && (
            <p className="text-center text-[10px] text-slate-400 font-bold uppercase tracking-widest py-6">
              Nada para resolver.
            </p>
          )}
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-navy-800 text-[10px] font-black uppercase"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-4 py-2 rounded-xl bg-navy-900 text-white text-[10px] font-black uppercase"
          >
            Continuar importação
          </button>
        </div>
      </div>
    </div>
  );
};

export default CsvResolveModal;
