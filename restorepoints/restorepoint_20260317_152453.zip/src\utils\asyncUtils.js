const waitMs = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const withRetry = async (fn, attempts = 3, baseDelay = 400) => {
  let lastError;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (e) {
      lastError = e;
      await waitMs(baseDelay * Math.pow(2, i));
    }
  }
  throw lastError;
};

export { waitMs, withRetry };
