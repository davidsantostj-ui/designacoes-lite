import { useEffect } from 'react';
import { CACHE_KEYS, safeLocalStorageSet } from '../utils/cacheUtils';

export const useCacheSync = (data) => {
  useEffect(() => {
    safeLocalStorageSet(CACHE_KEYS.users, data.users);
  }, [data.users]);
  useEffect(() => {
    safeLocalStorageSet(CACHE_KEYS.assignments, data.assignments);
  }, [data.assignments]);
  useEffect(() => {
    safeLocalStorageSet(CACHE_KEYS.notifications, data.notifications);
  }, [data.notifications]);
  useEffect(() => {
    safeLocalStorageSet(CACHE_KEYS.announcements, data.announcements);
  }, [data.announcements]);
  useEffect(() => {
    safeLocalStorageSet(CACHE_KEYS.swapLogs, data.swapLogs);
  }, [data.swapLogs]);
};
