import React from 'react';
import {
  Calendar as CalIcon,
  Megaphone,
  Repeat,
  ChevronLeft,
  ChevronRight,
  Pin,
  X
} from 'lucide-react';
import SkeletonBlock from '../SkeletonBlock';

const DashboardView = ({
  waReminder,
  sendWhatsAppReminder,
  activePinnedAnnouncement,
  handleOpenPinned,
  handleDismissPinned,
  setView,
  dataReady,
  data,
  unreadAnnouncementsCount,
  handleCalendarNavigate,
  monthLabel,
  monthWeeks,
  myAssignmentsByDate,
  selectedDate,
  setSelectedDate,
  setCalendarDate,
  formatAssignmentLabel,
  formatDatePt,
  dayAssignments,
  renderSkeletonList,
  myAssignmentsCount,
  isPastDate
}) => {
  const swapCount = (data.assignments || []).filter((a) => a.status === 'troca').length;
  return (
    <div className="p-5 space-y-5 animate-fade-in max-w-lg sm:max-w-xl lg:max-w-3xl mx-auto w-full">
      <section className="hero-gradient p-5 sm:p-6 rounded-3xl shadow-lg border border-slate-100/70 dark:border-slate-800/60 relative overflow-hidden">
        <span className="text-[10px] font-black uppercase tracking-widest opacity-60">
          Visão Geral
        </span>
        <h3 className="text-lg sm:text-xl font-black mt-1 leading-tight">Minhas Designações</h3>
        <p className="text-slate-600 text-sm mt-3 opacity-80 dark:text-slate-300 leading-relaxed max-w-[32ch]">
          Organização e colaboração digital para a congregação.
        </p>
      </section>
      {waReminder && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 p-4 rounded-3xl flex items-center justify-between">
          <div>
            <p className="text-xs font-black uppercase text-amber-700">Lembrete WhatsApp</p>
            <p className="text-sm font-bold">Designação em até 24h</p>
            <span className="text-[10px] text-slate-500">
              {waReminder.tipo_designacao} • {formatDatePt(waReminder.date)}
            </span>
          </div>
          <button
            onClick={() => sendWhatsAppReminder(waReminder)}
            className="px-3 py-2 bg-emerald-600 text-white text-[9px] font-black uppercase rounded-2xl"
          >
            Enviar
          </button>
        </div>
      )}
      {activePinnedAnnouncement && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 p-4 rounded-3xl flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Pin size={14} className="text-amber-600" />
              <p className="text-xs font-black uppercase text-amber-700">Anúncio fixado</p>
            </div>
            <p className="text-sm font-bold mt-1 truncate">{activePinnedAnnouncement.title}</p>
            <p className="text-[10px] text-slate-500 mt-1">{activePinnedAnnouncement.message}</p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <button
              onClick={() => handleOpenPinned(activePinnedAnnouncement.id)}
              className="px-3 py-1.5 bg-amber-600 text-white text-[9px] font-black uppercase rounded-2xl"
            >
              Ler
            </button>
            <button
              onClick={() => handleDismissPinned(activePinnedAnnouncement.id)}
              className="touch-target w-8 h-8 bg-white/70 text-slate-500 rounded-2xl"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        {[
          {
            id: 'ASSIGNMENTS_MONTH',
            label: 'Agenda',
            icon: CalIcon,
            tone: 'text-blue-500',
            chipClass: 'chip-blue',
            ready: dataReady.assignments,
            count: myAssignmentsCount
          },
          {
            id: 'SWAP_MARKET',
            label: 'Trocas',
            icon: Repeat,
            tone: 'text-orange-500',
            chipClass: 'chip-orange',
            ready: dataReady.assignments,
            count: swapCount
          },
          {
            id: 'ANNOUNCEMENTS',
            label: 'Anúncios',
            icon: Megaphone,
            tone: 'text-amber-500',
            chipClass: 'chip-amber',
            ready: dataReady.announcements,
            count: data.announcements.length,
            badge: unreadAnnouncementsCount
          }
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`relative card-surface min-h-[54px] sm:h-12 px-3 py-2 rounded-2xl shadow-sm flex items-center active:scale-95 transition-all ${item.chipClass}`}
          >
            <div className="grid grid-cols-[auto,1fr,auto] items-center gap-2 w-full">
              <item.icon className={item.tone} size={16} />
              <span className="text-[9px] sm:text-[10px] font-black text-slate-500 uppercase tracking-wider sm:tracking-widest leading-tight whitespace-normal sm:whitespace-nowrap sm:truncate">
                {item.label}
              </span>
              {item.ready ? (
                <span className="text-base sm:text-lg font-black dark:text-white leading-none justify-self-end">
                  {item.count}
                </span>
              ) : (
                <div className="justify-self-end">
                  <SkeletonBlock className="h-5 w-8" />
                </div>
              )}
            </div>
            {item.badge > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-red-500 text-white text-[9px] font-black rounded-full flex items-center justify-center">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="bg-white dark:bg-navy-800 card-surface p-4 sm:p-5 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between mb-3">
          <div>
            <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-400">
              Calendário
            </h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
              Designações (verde)
            </p>
          </div>
        </div>
        <div className="flex items-center justify-between mb-2">
          <button
            onClick={() => handleCalendarNavigate(-1)}
            className="touch-target w-8 h-8 rounded-full bg-slate-100 dark:bg-navy-900 text-slate-500 flex items-center justify-center"
          >
            <ChevronLeft size={16} />
          </button>
          <span className="text-sm font-semibold capitalize text-slate-600 min-w-[120px] text-center">
            {monthLabel}
          </span>
          <button
            onClick={() => handleCalendarNavigate(1)}
            className="touch-target w-8 h-8 rounded-full bg-slate-100 dark:bg-navy-900 text-slate-500 flex items-center justify-center"
          >
            <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid grid-cols-7 text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">
          {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom'].map((d) => (
            <div key={d} className="text-center py-1">
              {d}
            </div>
          ))}
        </div>
        <div className="space-y-1">
          {monthWeeks.map((week, wi) => (
            <div key={`w-${wi}`} className="grid grid-cols-7 gap-1">
              {week.map((day, di) => {
                const hasAssignments = myAssignmentsByDate[day.dateStr]?.length > 0;
                const isSelected = selectedDate === day.dateStr;
                const isPast = day.inMonth && isPastDate && isPastDate(day.dateStr);
                const baseBg = hasAssignments
                  ? isPast
                    ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-200'
                    : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-200'
                  : isPast
                    ? 'bg-slate-100 dark:bg-navy-900 text-slate-400 dark:text-slate-500'
                    : 'bg-slate-50 dark:bg-navy-900';
                const textTone = day.inMonth
                  ? isPast
                    ? 'text-slate-400 dark:text-slate-500'
                    : 'text-slate-800 dark:text-slate-100'
                  : 'text-slate-300';
                return (
                  <button
                    key={`d-${wi}-${di}`}
                    onClick={() => {
                      setSelectedDate(day.dateStr);
                      if (!day.inMonth) {
                        setCalendarDate(
                          new Date(day.date.getFullYear(), day.date.getMonth(), 1)
                        );
                      }
                    }}
                    className={`relative h-8 sm:h-9 rounded-xl text-xs font-bold ${textTone} ${baseBg} ${isSelected ? 'ring-2 ring-navy-900 dark:ring-blue-400' : ''}`}
                  >
                    {day.date.getDate()}
                    {hasAssignments && (
                      <span className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-2">
          <h4 className="text-[11px] sm:text-[12px] font-black uppercase tracking-widest text-slate-400">
            Agenda do dia
          </h4>
          <p className="text-[11px] sm:text-[12px] font-bold uppercase tracking-widest text-slate-400">
            Designações: {dayAssignments.length}
          </p>
          {!dataReady.assignments ? (
            <div className="space-y-2">{renderSkeletonList(3, 'h-12 w-full')}</div>
          ) : (
            <>
              {dayAssignments.map((a) => (
                <div
                  key={`cal-${a.id}`}
                  className="bg-slate-50 dark:bg-navy-900 p-3 rounded-2xl flex items-center justify-between"
                >
                  <div>
                    <p className="text-sm sm:text-base font-bold">
                      {formatAssignmentLabel(a.tipo_designacao)}
                    </p>
                    <span className="text-[11px] sm:text-xs text-slate-400">
                      {formatDatePt(a.date)}
                    </span>
                  </div>
                  <span
                    className={`text-[9px] sm:text-[10px] font-black px-2 py-1 rounded-full uppercase ${a.status === 'confirmado' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}
                  >
                    {a.status}
                  </span>
                </div>
              ))}
              {dayAssignments.length === 0 && (
                <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">
                  Nenhuma designação nessa data.
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardView;



