import React from 'react';
import {
  PlusCircle,
  Filter,
  UserCheck,
  BarChart2,
  Users,
  Mail,
  FileText,
  Database
} from 'lucide-react';
import AdminAssignmentsTab from '../../features/admin/AdminAssignmentsTab';
import AdminFiltersTab from '../../features/admin/AdminFiltersTab';
import AdminApprovalsTab from '../../features/admin/AdminApprovalsTab';
import AdminStatusTab from '../../features/admin/AdminStatusTab';
import AdminUsersTab from '../../features/admin/AdminUsersTab';
import AdminMessagesTab from '../../features/admin/AdminMessagesTab';
import AdminReportsTab from '../../features/admin/AdminReportsTab';
import AdminBackupTab from '../../features/admin/AdminBackupTab';

const AdminView = ({
  adminTab,
  setAdminTab,
  data,
  assignForm,
  setAssignForm,
  handleCreateAssignment,
  getUserAssignmentsOnDate,
  formatAssignmentLabel,
  ASSIGNMENT_TYPES,
  selectedUserAssignments,
  handlePickNextAvailable,
  freeUsersForSelectedDate,
  formatDatePt,
  monthCountsForSelected,
  getUserDisplayName,
  handleDownloadAssignmentsTemplate,
  isImportingAssignments,
  handleImportAssignmentsFile,
  reassigningId,
  setReassigningId,
  handleDeleteAssignment,
  handleReassign,
  filters,
  setFilters,
  STATUS_TYPES,
  filteredAssignments,
  handleUpdateApproval,
  handleApproveAll,
  handleApproveByDomain,
  user,
  isAdminUid,
  handleImpersonate,
  selectedAdminUser,
  setSelectedAdminUser,
  handleToggleAdminRole,
  handleDeleteUser,
  handleAdminUpdateUserName,
  handleSendBroadcast,
  assignmentReport,
  downloadCsv,
  handleExportBackup,
  handleImportBackup,
  handleFixMojibake,
  isFixingMojibake,
  handleCleanupAssignments,
  handleCleanupNotifications,
  isCleaningAssignments,
  isCleaningNotifications,
  handleWipeAssignments,
  isWipingAssignments,
  cleanupMonthLabel
}) => {
  return (
    <div className="animate-fade-in max-w-lg sm:max-w-xl lg:max-w-3xl mx-auto w-full">
      <div className="flex overflow-x-auto no-scrollbar bg-white dark:bg-navy-900 border-b px-4 pt-2 pb-2 sticky top-0 z-20 glass">
        {[
          { id: 'DESIGNACOES', icon: PlusCircle, label: 'Designar' },
          { id: 'FILTROS', icon: Filter, label: 'Busca' },
          { id: 'APROVACOES', icon: UserCheck, label: 'Aprovar' },
          { id: 'STATUS', icon: BarChart2, label: 'Status' },
          { id: 'USUARIOS', icon: Users, label: 'Gestão' },
          { id: 'MENSAGENS', icon: Mail, label: 'Avisos' },
          { id: 'RELATORIOS', icon: FileText, label: 'Relatórios' },
          { id: 'BACKUP', icon: Database, label: 'Backup' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setAdminTab(tab.id)}
            className={`flex flex-col items-center px-3 py-2 border-b-2 transition-all shrink-0 min-w-[72px] ${adminTab === tab.id ? 'border-navy-900 text-navy-900 dark:border-blue-400 dark:text-blue-400' : 'border-transparent text-slate-400'}`}
          >
            <tab.icon size={18} className="mb-1" />
            <span className="text-[9px] font-black uppercase tracking-widest leading-tight text-center">
              {tab.label}
            </span>
          </button>
        ))}
      </div>

      <div className="p-5 space-y-6">
        {adminTab === 'DESIGNACOES' && (
          <AdminAssignmentsTab
            data={data}
            assignForm={assignForm}
            setAssignForm={setAssignForm}
            handleCreateAssignment={handleCreateAssignment}
            getUserAssignmentsOnDate={getUserAssignmentsOnDate}
            formatAssignmentLabel={formatAssignmentLabel}
            ASSIGNMENT_TYPES={ASSIGNMENT_TYPES}
            selectedUserAssignments={selectedUserAssignments}
            handlePickNextAvailable={handlePickNextAvailable}
            freeUsersForSelectedDate={freeUsersForSelectedDate}
            formatDatePt={formatDatePt}
            monthCountsForSelected={monthCountsForSelected}
            getUserDisplayName={getUserDisplayName}
            handleDownloadAssignmentsTemplate={handleDownloadAssignmentsTemplate}
            isImportingAssignments={isImportingAssignments}
            handleImportAssignmentsFile={handleImportAssignmentsFile}
            reassigningId={reassigningId}
            setReassigningId={setReassigningId}
            handleDeleteAssignment={handleDeleteAssignment}
            handleReassign={handleReassign}
          />
        )}

        {adminTab === 'FILTROS' && (
          <AdminFiltersTab
            data={data}
            filters={filters}
            setFilters={setFilters}
            STATUS_TYPES={STATUS_TYPES}
            filteredAssignments={filteredAssignments}
            formatDatePt={formatDatePt}
            formatAssignmentLabel={formatAssignmentLabel}
            getUserDisplayName={getUserDisplayName}
          />
        )}

        {adminTab === 'APROVACOES' && (
          <AdminApprovalsTab
            data={data}
            handleUpdateApproval={handleUpdateApproval}
            handleApproveAll={handleApproveAll}
            handleApproveByDomain={handleApproveByDomain}
          />
        )}

        {adminTab === 'STATUS' && <AdminStatusTab data={data} />}

        {adminTab === 'USUARIOS' && (
          <AdminUsersTab
            data={data}
            user={user}
            isAdminUid={isAdminUid}
            handleImpersonate={handleImpersonate}
            selectedAdminUser={selectedAdminUser}
            setSelectedAdminUser={setSelectedAdminUser}
            handleToggleAdminRole={handleToggleAdminRole}
            handleDeleteUser={handleDeleteUser}
            handleUpdateUserName={handleAdminUpdateUserName}
          />
        )}

        {adminTab === 'MENSAGENS' && <AdminMessagesTab handleSendBroadcast={handleSendBroadcast} />}

        {adminTab === 'RELATORIOS' && (
          <AdminReportsTab
            assignmentReport={assignmentReport}
            data={data}
            downloadCsv={downloadCsv}
          />
        )}

        {adminTab === 'BACKUP' && (
          <AdminBackupTab
            handleExportBackup={handleExportBackup}
            handleImportBackup={handleImportBackup}
            handleFixMojibake={handleFixMojibake}
            isFixingMojibake={isFixingMojibake}
            handleCleanupAssignments={handleCleanupAssignments}
            handleCleanupNotifications={handleCleanupNotifications}
            isCleaningAssignments={isCleaningAssignments}
            isCleaningNotifications={isCleaningNotifications}
            handleWipeAssignments={handleWipeAssignments}
            isWipingAssignments={isWipingAssignments}
            cleanupMonthLabel={cleanupMonthLabel}
          />
        )}
      </div>
    </div>
  );
};

export default AdminView;
