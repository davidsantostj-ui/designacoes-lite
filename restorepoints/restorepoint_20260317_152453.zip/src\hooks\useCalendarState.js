import { useCallback, useMemo, useState } from 'react';
import { formatIsoDateLocal, getMonthMatrix } from '../utils/dateUtils';

export const useCalendarState = ({
  assignments,
  user,
  formatAssignmentLabel,
  formatDatePt
}) => {
  const [selectedDate, setSelectedDate] = useState(() => formatIsoDateLocal(new Date()));
  const [calendarDate, setCalendarDate] = useState(() => new Date());

  const monthWeeks = useMemo(() => getMonthMatrix(calendarDate), [calendarDate]);
  const monthLabel = useMemo(
    () => calendarDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }),
    [calendarDate]
  );

  const myAssignmentsByDate = useMemo(() => {
    const map = {};
    assignments
      .filter((a) => a.usuario_id === user?.id)
      .forEach((a) => {
      if (!a?.date) return;
      if (!map[a.date]) map[a.date] = [];
      map[a.date].push(a);
    });
    return map;
  }, [assignments, user]);

  const dayAssignments = useMemo(
    () => myAssignmentsByDate[selectedDate] || [],
    [myAssignmentsByDate, selectedDate]
  );

  const myAssignmentsCount = useMemo(() => {
    if (!user) return 0;
    return assignments.filter((a) => a.usuario_id === user.id).length;
  }, [assignments, user]);

  const handleCalendarNavigate = useCallback((offset) => {
    setCalendarDate((prev) => {
      const next = new Date(prev.getFullYear(), prev.getMonth() + offset, 1);
      setSelectedDate(formatIsoDateLocal(next));
      return next;
    });
  }, []);

  const formattedDayAssignments = useMemo(() => {
    return dayAssignments.map((a) => ({
      ...a,
      label: formatAssignmentLabel(a.tipo_designacao),
      dateLabel: formatDatePt(a.date)
    }));
  }, [dayAssignments, formatAssignmentLabel, formatDatePt]);

  return {
    selectedDate,
    setSelectedDate,
    calendarDate,
    setCalendarDate,
    monthWeeks,
    monthLabel,
    myAssignmentsByDate,
    dayAssignments,
    myAssignmentsCount,
    handleCalendarNavigate,
    formattedDayAssignments
  };
};
