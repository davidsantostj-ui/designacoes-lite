﻿import React from 'react';
import { Send } from 'lucide-react';

const AdminMessagesTab = ({ handleSendBroadcast }) => {
  return (
    <form
      className="bg-white dark:bg-navy-800 card-surface p-6 rounded-4xl shadow-md space-y-4"
      onSubmit={handleSendBroadcast}
    >
      <h3 className="text-xs font-black uppercase text-slate-400">Comunicado Oficial</h3>
      <textarea
        name="msg"
        placeholder="Texto que todos verão no histórico de notificações..."
        className="w-full p-4 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm min-h-[150px] border-none outline-none resize-none"
        required
      />
      <button
        type="submit"
        className="w-full bg-navy-900 text-white font-black py-4 rounded-2xl text-[10px] uppercase tracking-widest active:scale-95 shadow-xl flex items-center justify-center gap-2"
      >
        <Send size={16} /> DISPARAR AGORA
      </button>
    </form>
  );
};

export default AdminMessagesTab;
