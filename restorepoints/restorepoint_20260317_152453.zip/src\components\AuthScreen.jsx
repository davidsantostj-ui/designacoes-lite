import React from 'react';
import { CalendarPlus } from 'lucide-react';
import Toast from './Toast';

const AuthScreen = ({
  toasts = [],
  onCloseToast,
  loginState,
  setLoginState,
  isLoading,
  onLogin,
  onResetPassword,
  onRegister
}) => {
  return (
    <div className="min-h-screen bg-transparent flex flex-col items-center justify-center p-6 animate-fade-in relative overflow-hidden text-slate-900 dark:text-slate-100">
      {toasts.map((t) => (
        <Toast
          key={t.id}
          msg={t.msg}
          type={t.type}
          onClose={() => onCloseToast && onCloseToast(t.id)}
        />
      ))}
      <div className="bg-white dark:bg-navy-900 card-surface rounded-5xl p-8 w-full max-w-sm shadow-2xl relative z-10 border dark:border-slate-800">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-sky-400 text-white rounded-3xl mx-auto flex items-center justify-center shadow-xl mb-4">
            <CalendarPlus size={30} />
          </div>
          <h1 className="text-2xl font-black text-navy-900 dark:text-white tracking-tight">
            Minhas Designações
          </h1>
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mt-2">
            Acesso Seguro
          </p>
        </div>

        {loginState === 'SIGNIN' && (
          <form className="space-y-4" onSubmit={onLogin}>
            <input
              name="email"
              type="email"
              placeholder="E-mail"
              className="w-full p-4 bg-slate-50 dark:bg-navy-800 rounded-2xl font-semibold text-sm"
              required
            />
            <input
              name="password"
              type="password"
              placeholder="Senha"
              className="w-full p-4 bg-slate-50 dark:bg-navy-800 rounded-2xl text-center tracking-[0.2em] text-lg font-bold"
              required
            />
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-navy-900 text-white font-black py-4 rounded-2xl shadow-lg active:scale-95 transition-all uppercase tracking-widest text-xs"
            >
              Entrar
            </button>
            <button
              type="button"
              onClick={() => setLoginState('RESET')}
              className="w-full py-2 text-[10px] font-black text-slate-500 uppercase tracking-widest"
            >
              Recuperar senha
            </button>
            <button
              type="button"
              onClick={() => setLoginState('REGISTER')}
              className="w-full py-2 text-[10px] font-black text-navy-600 dark:text-blue-400 uppercase tracking-widest"
            >
              Novo cadastro
            </button>
          </form>
        )}

        {loginState === 'RESET' && (
          <form className="space-y-4" onSubmit={onResetPassword}>
            <input
              name="email"
              type="email"
              placeholder="E-mail"
              className="w-full p-4 bg-slate-50 dark:bg-navy-800 rounded-2xl font-semibold text-sm"
              required
            />
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center">
              Enviaremos um link para redefinir sua senha.
            </p>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-emerald-600 text-white font-black py-4 rounded-2xl shadow-lg active:scale-95 uppercase tracking-widest text-xs"
            >
              Enviar link
            </button>
            <button
              type="button"
              onClick={() => setLoginState('SIGNIN')}
              className="w-full py-2 text-[10px] font-black text-slate-500 uppercase tracking-widest"
            >
              Voltar
            </button>
          </form>
        )}

        {loginState === 'REGISTER' && (
          <form className="space-y-3" onSubmit={onRegister}>
            <div className="flex gap-2">
              <input
                name="name"
                placeholder="Nome"
                className="w-1/2 p-3 bg-slate-50 dark:bg-navy-800 rounded-xl text-sm"
                required
              />
              <input
                name="surname"
                placeholder="Sobrenome"
                className="w-1/2 p-3 bg-slate-50 dark:bg-navy-800 rounded-xl text-sm"
                required
              />
            </div>
            <input
              name="phone"
              placeholder="WhatsApp"
              className="w-full p-3 bg-slate-50 dark:bg-navy-800 rounded-xl text-sm"
              required
            />
            <input
              name="email"
              type="email"
              placeholder="E-mail"
              className="w-full p-3 bg-slate-50 dark:bg-navy-800 rounded-xl text-sm"
              required
            />
            <input
              name="password"
              type="password"
              placeholder="Senha"
              className="w-full p-3 bg-slate-50 dark:bg-navy-800 rounded-xl text-center tracking-[0.2em] font-bold"
              required
            />
            <input
              name="password2"
              type="password"
              placeholder="Repetir senha"
              className="w-full p-3 bg-slate-50 dark:bg-navy-800 rounded-xl text-center tracking-[0.2em] font-bold"
              required
            />
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-emerald-600 text-white font-black py-4 rounded-2xl shadow-lg active:scale-95 uppercase tracking-widest text-xs"
            >
              Solicitar Acesso
            </button>
            <button
              type="button"
              onClick={() => setLoginState('SIGNIN')}
              className="w-full py-2 text-[10px] font-black text-slate-500 uppercase tracking-widest"
            >
              Voltar
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default AuthScreen;
