﻿import React from 'react';
import { RefreshCw, Trash2 } from 'lucide-react';

const AdminAssignmentsTab = ({
  data,
  assignForm,
  setAssignForm,
  handleCreateAssignment,
  getUserAssignmentsOnDate,
  formatAssignmentLabel,
  ASSIGNMENT_TYPES,
  selectedUserAssignments,
  handlePickNextAvailable,
  freeUsersForSelectedDate,
  formatDatePt,
  monthCountsForSelected,
  getUserDisplayName,
  handleDownloadAssignmentsTemplate,
  isImportingAssignments,
  handleImportAssignmentsFile,
  reassigningId,
  setReassigningId,
  handleDeleteAssignment,
  handleReassign
}) => {
  return (
    <div className="space-y-6">
      <form
        className="bg-white dark:bg-navy-800 card-surface p-6 rounded-4xl shadow-md space-y-4"
        onSubmit={handleCreateAssignment}
      >
        <h3 className="text-xs font-black uppercase text-slate-400">Nova Designação</h3>
        <input
          name="date"
          type="date"
          value={assignForm.date}
          onChange={(e) => setAssignForm((prev) => ({ ...prev, date: e.target.value }))}
          className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm border dark:border-slate-700"
          required
        />
        <select
          name="user"
          value={assignForm.userId}
          onChange={(e) => setAssignForm((prev) => ({ ...prev, userId: e.target.value }))}
          className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm font-semibold border dark:border-slate-700"
          required
        >
          <option value="">Selecione o Irmão</option>
          {data.users
            .filter((u) => u.approved)
            .map((u) => {
              const dayAssignments = assignForm.date
                ? getUserAssignmentsOnDate(u.id, assignForm.date)
                : [];
              let status = '';
              if (assignForm.date) {
                if (dayAssignments.length === 0) status = 'livre';
                else if (dayAssignments.length === 1)
                  status = `ocupado: ${formatAssignmentLabel(dayAssignments[0].tipo_designacao)}`;
                else status = `ocupado: ${dayAssignments.length} tarefas`;
              }
              return (
                <option key={u.id} value={u.id}>
                  {u.name} {u.surname}
                  {status ? ` — ${status}` : ''}
                </option>
              );
            })}
        </select>
        <select
          name="type"
          value={assignForm.type}
          onChange={(e) => setAssignForm((prev) => ({ ...prev, type: e.target.value }))}
          className="w-full p-3 bg-slate-50 dark:bg-navy-900 rounded-xl text-sm font-semibold border dark:border-slate-700"
          required
        >
          <option value="">Tarefa</option>
          {ASSIGNMENT_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
        {assignForm.date && assignForm.userId && (
          <div
            className={`p-3 rounded-2xl text-[9px] font-black uppercase tracking-widest ${selectedUserAssignments.length ? 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-300' : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-300'}`}
          >
            {selectedUserAssignments.length === 0 && 'Livre nessa data.'}
            {selectedUserAssignments.length > 0 &&
              `Já possui ${selectedUserAssignments.length} designação(ões) nessa data.`}
            {selectedUserAssignments.length > 0 &&
              assignForm.type &&
              selectedUserAssignments.some((a) => a.tipo_designacao === assignForm.type) &&
              ' (mesmo tipo)'}
          </div>
        )}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePickNextAvailable}
            disabled={!assignForm.date || freeUsersForSelectedDate.length === 0}
            className="flex-1 bg-slate-100 dark:bg-navy-900 text-slate-600 dark:text-slate-300 font-black py-3 rounded-2xl text-[9px] uppercase tracking-widest disabled:opacity-60"
          >
            Próximo disponível
          </button>
          <button
            type="button"
            onClick={() => setAssignForm((prev) => ({ ...prev, userId: '', type: '' }))}
            className="px-3 py-3 rounded-2xl bg-white dark:bg-navy-900 text-[9px] font-black uppercase tracking-widest text-slate-400"
          >
            Limpar
          </button>
        </div>
        {assignForm.date ? (
          <div className="bg-slate-50 dark:bg-navy-900/60 p-4 rounded-3xl space-y-3 border dark:border-slate-800">
            <div className="flex items-center justify-between">
              <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">
                Irmãos livres em {formatDatePt(assignForm.date)}
              </p>
              <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">
                {freeUsersForSelectedDate.length}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {freeUsersForSelectedDate.slice(0, 6).map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => setAssignForm((prev) => ({ ...prev, userId: u.id }))}
                  className="p-3 rounded-2xl bg-white dark:bg-navy-800 border dark:border-slate-800 text-left hover:shadow-sm transition-all"
                >
                  <p className="text-xs font-bold truncate">{getUserDisplayName(u)}</p>
                  <p className="text-[9px] text-slate-400 uppercase font-bold tracking-widest">
                    {monthCountsForSelected[u.id] || 0} no mês
                  </p>
                </button>
              ))}
              {freeUsersForSelectedDate.length === 0 && (
                <p className="col-span-1 sm:col-span-2 text-center text-[10px] text-slate-400 font-bold uppercase tracking-widest py-4">
                  Todos ocupados nessa data.
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-slate-50 dark:bg-navy-900/60 p-4 rounded-3xl text-[9px] font-black uppercase tracking-widest text-slate-400 text-center border dark:border-slate-800">
            Selecione uma data para ver quem está livre.
          </div>
        )}
        <button
          type="submit"
          className="w-full bg-navy-900 text-white font-black py-4 rounded-2xl text-[10px] uppercase tracking-widest active:scale-95 shadow-lg"
        >
          SALVAR
        </button>
      </form>
      <div className="bg-white dark:bg-navy-800 card-surface p-6 rounded-4xl shadow-md space-y-4">
        <h3 className="text-xs font-black uppercase text-slate-400">Importar Designações (CSV)</h3>
        <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">
          Um aviso por usuário com o total de designações importadas.
        </p>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={handleDownloadAssignmentsTemplate}
            className="flex-1 bg-slate-100 dark:bg-navy-900 text-slate-600 dark:text-slate-300 font-black py-3 rounded-2xl text-[9px] uppercase tracking-widest"
          >
            Baixar modelo
          </button>
          <label className="flex-1 bg-emerald-600 text-white font-black py-3 rounded-2xl text-[9px] uppercase tracking-widest text-center cursor-pointer">
            {isImportingAssignments ? 'Importando...' : 'Selecionar CSV'}
            <input
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              disabled={isImportingAssignments}
              onChange={(e) => handleImportAssignmentsFile(e.target.files?.[0])}
            />
          </label>
        </div>
        <p className="text-[9px] text-slate-400 uppercase font-bold tracking-widest">
          Colunas aceitas: uid (opcional), nome, tarefa, data, status.
        </p>
        <p className="text-[9px] text-slate-400 uppercase font-bold tracking-widest">
          Datas: 10/02/2026 ou 2026-02-10.
        </p>
      </div>
      <div className="space-y-4">
        <h4 className="text-[9px] font-black uppercase text-slate-400 px-1">Últimas 15</h4>
        {data.assignments.slice(0, 15).map((a) => (
          <div
            key={a.id}
            className="bg-white dark:bg-navy-800 p-4 rounded-3xl shadow-sm flex flex-col gap-2 animate-slide-up border dark:border-slate-800"
          >
            <div className="flex justify-between items-center">
              <div className="min-w-0">
                <p className="text-[9px] font-black text-blue-500 uppercase tracking-widest">
                  {formatDatePt(a.date)}
                </p>
                <p className="font-bold text-sm truncate dark:text-white">
                  {formatAssignmentLabel(a.tipo_designacao)}
                </p>
                <p className="text-[10px] text-slate-400 font-black uppercase">
                  {getUserDisplayName(data.users.find((u) => u.id === a.usuario_id))}
                </p>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={() => setReassigningId(reassigningId === a.id ? null : a.id)}
                  className={`touch-target w-9 h-9 rounded-full ${reassigningId === a.id ? 'bg-navy-900 text-white' : 'text-slate-400 hover:bg-slate-100'}`}
                  title="Reatribuir"
                >
                  <RefreshCw size={16} />
                </button>
                <button
                  onClick={() => handleDeleteAssignment(a.id)}
                  className="touch-target w-9 h-9 text-red-500 hover:bg-red-50 rounded-full"
                  title="Excluir"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            {reassigningId === a.id && (
              <div className="pt-2 border-t dark:border-slate-700 flex flex-col gap-2 animate-fade-in">
                <span className="text-[8px] font-black uppercase text-slate-400">
                  Alterar responsável:
                </span>
                <select
                  onChange={(e) => handleReassign(a.id, e.target.value)}
                  className="w-full p-2 bg-slate-100 dark:bg-navy-950 rounded-lg text-xs font-bold border-none outline-none"
                >
                  <option value="">Escolha um irmão...</option>
                  {data.users
                    .filter((u) => u.approved && u.id !== a.usuario_id)
                    .map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} {u.surname}
                      </option>
                    ))}
                </select>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminAssignmentsTab;
