import { ASSIGNMENT_TYPES } from '../constants/appConstants';
import { stripAccents } from './textUtils';

const formatAssignmentLabel = (type) => {
  if (type === 'LANCHE_ORADOR') return 'Lanche do Orador';
  return type;
};

const normalizeAssignmentType = (value) => {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const cleaned = stripAccents(raw).toLowerCase();
  const aliases = {
    'sistema de som': 'Sistema de Áudio',
    'sistema de audio': 'Sistema de Áudio',
    'indicador de auditorio': 'Indicador Auditório',
    'leitor de a sentinela': 'Leitor A Sentinela',
    'leitor da sentinela': 'Leitor A Sentinela',
    'presidente fim de semana': 'Presidente Fim de Semana',
    'lanche orador': 'Lanche do Orador',
    'lanche do orador': 'LANCHE_ORADOR'
  };
  if (aliases[cleaned]) return aliases[cleaned];
  const match = ASSIGNMENT_TYPES.find((t) => stripAccents(t).toLowerCase() === cleaned);
  return match || raw;
};

export { formatAssignmentLabel, normalizeAssignmentType };
