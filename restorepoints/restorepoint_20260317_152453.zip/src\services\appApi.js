import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  serverTimestamp,
  writeBatch
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export function createAppApi({ auth, db, storage, ensureAuth, withRetry }) {
  const ensureSignedIn = ensureAuth
    ? ensureAuth
    : async () => {
        if (!auth?.currentUser) throw new Error('not-authenticated');
        return auth.currentUser;
      };

  const compressImage = (file) => {
    if (!file || !file.type.startsWith('image/')) return Promise.resolve(file);
    return new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        const maxWidth = 1024;
        const scale = Math.min(1, maxWidth / img.width);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(
          (blob) => {
            URL.revokeObjectURL(url);
            resolve(blob || file);
          },
          'image/jpeg',
          0.8
        );
      };
      img.onerror = () => resolve(file);
      img.src = url;
    });
  };

  const uploadFile = async (file, pathPrefix = 'uploads') => {
    if (!file) return null;
    if (file.type && file.type.startsWith('video/')) {
      throw new Error('Vídeos não permitidos');
    }
    if (file.size && file.size > 20 * 1024 * 1024) {
      throw new Error('Arquivo acima de 20MB');
    }
    let payload = file;
    if (file.type && file.type.startsWith('image/')) {
      payload = await compressImage(file);
    }
    const safeName = `${Date.now()}_${file.name || 'arquivo'}`;
    const storageRef = ref(storage, `${pathPrefix}/${safeName}`);
    await uploadBytes(storageRef, payload);
    const url = await getDownloadURL(storageRef);
    return {
      url,
      name: file.name || 'arquivo',
      type: file.type || 'application/octet-stream',
      size: file.size || 0
    };
  };

  const createAnnouncement = async ({ title, message, pinned, authorId }) => {
    await ensureSignedIn();
    return addDoc(collection(db, 'announcements'), {
      title,
      message,
      pinned: !!pinned,
      authorId,
      created_at: serverTimestamp(),
      read_by: authorId ? [authorId] : []
    });
  };

  const deleteAnnouncement = async (id) => {
    await ensureSignedIn();
    return deleteDoc(doc(db, 'announcements', id));
  };

  const exportData = async () => {
    await ensureSignedIn();
    const collections = ['users', 'assignments', 'notifications', 'audit_logs', 'swap_requests'];
    const data = {};
    for (const col of collections) {
      const snap = await withRetry(() => getDocs(collection(db, col)));
      data[col] = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    }
    return data;
  };

  const importData = async (payload) => {
    await ensureSignedIn();
    const collections = ['users', 'assignments', 'notifications', 'audit_logs', 'swap_requests'];
    const entries = [];
    collections.forEach((col) => {
      const docs = payload?.[col] || [];
      docs.forEach((item) => {
        const { id, ...rest } = item;
        entries.push({ col, id, data: rest });
      });
    });
    const chunks = [];
    for (let i = 0; i < entries.length; i += 450) {
      chunks.push(entries.slice(i, i + 450));
    }
    for (const chunk of chunks) {
      const batch = writeBatch(db);
      chunk.forEach((e) => {
        const refDoc = doc(db, e.col, e.id || doc(collection(db, e.col)).id);
        batch.set(refDoc, e.data, { merge: true });
      });
      await batch.commit();
    }
  };

  return {
    compressImage,
    uploadFile,
    createAnnouncement,
    deleteAnnouncement,
    exportData,
    importData
  };
}
