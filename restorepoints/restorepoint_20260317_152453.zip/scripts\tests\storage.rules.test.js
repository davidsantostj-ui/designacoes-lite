﻿const fs = require('fs');
const { initializeTestEnvironment, assertFails } = require('@firebase/rules-unit-testing');
const { ref, uploadBytes } = require('firebase/storage');

let testEnv;

describe('Storage rules - chat disabled', function () {
  this.timeout(20000);

  before(async () => {
    const rules = fs.readFileSync('storage.rules', 'utf8');
    testEnv = await initializeTestEnvironment({
      projectId: 'minhas-designacoes-app',
      storage: { rules }
    });

    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      await db.doc('users/alice').set({ approved: true, email: 'alice@example.com' });
      await db.doc('users/bob').set({ approved: false, email: 'bob@example.com' });
    });
  });

  after(async () => {
    await testEnv.clearFirestore();
    await testEnv.cleanup();
  });

  it('approved user cannot upload to chats', async () => {
    const aliceStorage = testEnv.authenticatedContext({ uid: 'alice' }).storage();
    const fileRef = aliceStorage.ref('chats/room1/image.png');
    const data = new Uint8Array([0, 1, 2, 3]);
    await assertFails(uploadBytes(fileRef, data, { contentType: 'image/png' }));
  });

  it('unapproved user cannot upload to chats', async () => {
    const bobStorage = testEnv.authenticatedContext({ uid: 'bob' }).storage();
    const fileRef = bobStorage.ref('chats/room1/bad.png');
    const data = new Uint8Array([0, 1]);
    await assertFails(uploadBytes(fileRef, data, { contentType: 'image/png' }));
  });
});
