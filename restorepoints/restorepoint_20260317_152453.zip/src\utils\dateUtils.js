const formatDatePt = (dateStr) => (dateStr ? dateStr.split('-').reverse().join('/') : '');

const getFriendlyTime = (timestamp) => {
  if (!timestamp) return '';
  const now = new Date();
  const msgDate = timestamp?.toDate
    ? timestamp.toDate()
    : timestamp instanceof Date
      ? timestamp
      : new Date(timestamp);
  if (isNaN(msgDate.getTime())) return '';
  const diffDays = Math.floor((now - msgDate) / (1000 * 60 * 60 * 24));
  if (diffDays === 0) return msgDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (diffDays === 1) return 'Ontem';
  return msgDate.toLocaleDateString([], { day: '2-digit', month: '2-digit' });
};

const formatChatDay = (timestamp) => {
  if (!timestamp) return '';
  const msgDate = timestamp?.toDate
    ? timestamp.toDate()
    : timestamp instanceof Date
      ? timestamp
      : new Date(timestamp);
  if (isNaN(msgDate.getTime())) return '';
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const msgDay = new Date(msgDate.getFullYear(), msgDate.getMonth(), msgDate.getDate());
  const diffDays = Math.round((today - msgDay) / (1000 * 60 * 60 * 24));
  if (diffDays === 0) return 'Hoje';
  if (diffDays === 1) return 'Ontem';
  return msgDate.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
};

const formatIsoDateLocal = (date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const getDateDaysAgo = (days) => {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return formatIsoDateLocal(date);
};

const getMonthStartIso = (baseDate = new Date()) => {
  const start = new Date(baseDate.getFullYear(), baseDate.getMonth(), 1);
  return formatIsoDateLocal(start);
};

const isPastDate = (dateStr) => {
  if (!dateStr) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const d = new Date(`${dateStr}T00:00:00`);
  return d < today;
};

const getMonthMatrix = (date) => {
  const year = date.getFullYear();
  const month = date.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startWeekday = (firstDay.getDay() + 6) % 7; // Monday=0
  const daysInMonth = lastDay.getDate();
  const weeks = [];
  let day = 1 - startWeekday;
  while (day <= daysInMonth) {
    const week = [];
    for (let i = 0; i < 7; i++) {
      const current = new Date(year, month, day);
      const inMonth = current.getMonth() === month;
      const dateStr = `${current.getFullYear()}-${String(current.getMonth() + 1).padStart(2, '0')}-${String(current.getDate()).padStart(2, '0')}`;
      week.push({ date: current, dateStr, inMonth });
      day++;
    }
    weeks.push(week);
  }
  return weeks;
};

export {
  formatDatePt,
  getFriendlyTime,
  formatChatDay,
  formatIsoDateLocal,
  getDateDaysAgo,
  getMonthStartIso,
  isPastDate,
  getMonthMatrix
};
