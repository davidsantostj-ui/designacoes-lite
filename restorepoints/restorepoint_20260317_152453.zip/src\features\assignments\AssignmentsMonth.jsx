import React, { useMemo, useState } from 'react';

const AssignmentsMonth = ({
  data,
  dataReady,
  user,
  renderSkeletonList,
  formatDatePt,
  formatAssignmentLabel,
  isPastDate,
  handleAccept,
  handleSwapRequest,
  handleCancelSwap,
  downloadIcs,
  openSwapLogId,
  setOpenSwapLogId,
  swapLogsByAssignment,
  getUserDisplayName,
  getFriendlyTime,
  onLoadMore,
  hasMore,
  isLoadingMore
}) => {
  const [statusFilter, setStatusFilter] = useState('all');
  const myAssignments = data.assignments
    .filter((a) => a.usuario_id === user.id)
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  const filteredAssignments = useMemo(() => {
    if (statusFilter === 'all') return myAssignments;
    return myAssignments.filter((a) => a.status === statusFilter);
  }, [myAssignments, statusFilter]);
  const agendaItems = filteredAssignments
    .map((a) => ({ kind: 'assignment', date: a.date, item: a }))
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  const isLoading = !dataReady.assignments;

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-black px-1 uppercase tracking-tighter">Minha Agenda</h2>
      <div className="flex flex-wrap gap-2 px-1">
        {[{
          id: 'all',
          label: 'Todas',
          tone: 'bg-slate-100 text-slate-600'
        },
        {
          id: 'pendente',
          label: 'Pendentes',
          tone: 'bg-amber-100 text-amber-700'
        },
        {
          id: 'confirmado',
          label: 'Confirmadas',
          tone: 'bg-emerald-100 text-emerald-700'
        },
        {
          id: 'troca',
          label: 'Trocas',
          tone: 'bg-orange-100 text-orange-700'
        }].map((opt) => (
          <button
            key={opt.id}
            type="button"
            onClick={() => setStatusFilter(opt.id)}
            className={`px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest transition-all ${
              statusFilter === opt.id
                ? `${opt.tone} shadow-sm`
                : 'bg-white text-slate-400 border border-slate-200'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>
      {isLoading ? (
        <div className="space-y-3">{renderSkeletonList(4, 'h-24 w-full')}</div>
      ) : (
        <>
          {agendaItems.map((entry) => {
            const a = entry.item;
            const isPast = isPastDate(a.date);
            return (
              <div
                key={a.id}
                className={`card-surface p-5 rounded-4xl shadow-sm relative overflow-hidden animate-slide-up border ${isPast ? 'bg-slate-50/80 dark:bg-navy-900/70 border-slate-200 dark:border-slate-700' : 'bg-white dark:bg-navy-800 border-slate-200 dark:border-slate-800'}`}
              >
                <div className="absolute top-0 left-0 w-1.5 h-full bg-navy-900 dark:bg-blue-500"></div>
                <span
                  className={`text-[9px] font-black uppercase tracking-widest ${isPast ? 'text-slate-400 dark:text-slate-400' : 'text-navy-900 dark:text-blue-500'}`}
                >
                  {formatDatePt(a.date)}
                </span>
                <h3
                  className={`text-base font-black mt-1 leading-tight ${isPast ? 'text-slate-600 dark:text-slate-300' : 'dark:text-white'}`}
                >
                  {formatAssignmentLabel(a.tipo_designacao)}
                </h3>
                <div className="mt-5 flex justify-between items-center">
                  <span
                    className={`text-[8px] font-black uppercase px-3 py-1.5 rounded-full tracking-widest ${a.status === 'confirmado' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}
                  >
                    {a.status}
                  </span>
                  <div className="flex gap-2">
                    {a.status === 'confirmado' && (
                      <button
                        onClick={() => downloadIcs(a)}
                        className="text-[9px] font-black uppercase text-blue-600 bg-blue-50 dark:bg-blue-900/20 px-4 py-2.5 rounded-2xl active:scale-90 transition-colors"
                      >
                        ?? Agenda
                      </button>
                    )}
                    {!isPastDate(a.date) && a.status === 'pendente' && (
                      <button
                        onClick={() => handleAccept(a.id)}
                        className="text-[9px] font-black uppercase text-white bg-emerald-600 px-5 py-2.5 rounded-2xl active:scale-90 shadow-md"
                      >
                        Aceitar
                      </button>
                    )}
                    {!isPastDate(a.date) && a.status !== 'troca' && (
                      <button
                        onClick={() => handleSwapRequest(a)}
                        className="text-[9px] font-black uppercase text-orange-600 bg-orange-50 dark:bg-orange-900/20 px-5 py-2.5 rounded-2xl active:scale-90 transition-colors"
                      >
                        Solicitar Troca
                      </button>
                    )}
                    {!isPastDate(a.date) && a.status === 'troca' && (
                      <button
                        onClick={() => handleCancelSwap(a)}
                        className="text-[9px] font-black uppercase text-slate-600 bg-slate-100 dark:bg-navy-700 px-5 py-2.5 rounded-2xl active:scale-90 transition-colors"
                      >
                        Cancelar Troca
                      </button>
                    )}
                  </div>
                </div>
                <div className="mt-4">
                  <button
                    onClick={() => setOpenSwapLogId(openSwapLogId === a.id ? null : a.id)}
                    className="text-[9px] font-black uppercase text-slate-500 bg-slate-100 dark:bg-navy-700 px-4 py-2 rounded-2xl"
                  >
                    {openSwapLogId === a.id ? 'Ocultar Hist�rico' : 'Ver Hist�rico'}
                  </button>
                  {openSwapLogId === a.id && (
                    <div className="mt-3 space-y-2">
                      {(swapLogsByAssignment[a.id] || []).slice(0, 5).map((l) => {
                        const who =
                          getUserDisplayName(data.users.find((u) => u.id === l.actorId)) ||
                          'Usu�rio';
                        const actionLabel =
                          l.action === 'solicitar_troca'
                            ? 'Solicitou troca'
                            : l.action === 'cancelar_troca'
                              ? 'Cancelou troca'
                              : l.action === 'aceitar_troca'
                                ? 'Aceitou troca'
                                : 'Atualiza��o';
                        return (
                          <div
                            key={l.id}
                            className="text-[10px] text-slate-500 bg-slate-50 dark:bg-navy-900 p-2 rounded-xl"
                          >
                            <span className="font-bold">{who}</span> � {actionLabel} �{' '}
                            {getFriendlyTime(l.createdAt)}
                          </div>
                        );
                      })}
                      {(swapLogsByAssignment[a.id] || []).length === 0 && (
                        <p className="text-[10px] text-slate-400">Sem hist�rico.</p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {agendaItems.length === 0 && (
            <p className="text-center text-xs text-slate-400 py-20 font-bold uppercase tracking-widest">
              Agenda livre para voc�.
            </p>
          )}
          {hasMore && (
            <button
              type="button"
              onClick={() => onLoadMore && onLoadMore()}
              disabled={isLoadingMore}
              className="w-full bg-white dark:bg-navy-800 card-surface py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 disabled:opacity-60"
            >
              {isLoadingMore ? 'Carregando...' : 'Carregar mais'}
            </button>
          )}
        </>
      )}
    </div>
  );
};

export default AssignmentsMonth;





