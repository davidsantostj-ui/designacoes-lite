export const useNotificationActions = ({
  db,
  user,
  addToast,
  confirm,
  runExclusive,
  guardAuth,
  setUser,
  setData,
  resolveNotificationTarget,
  setView,
  doc,
  updateDoc,
  arrayUnion,
  serverTimestamp
}) => {
  const handleClearNotifications = async () => {
    const confirmed = await confirm({
      title: 'Limpar notificações',
      message: 'Deseja limpar todas as notificações?',
      confirmText: 'Limpar'
    });
    if (!confirmed) return;
    await runExclusive('clear_notifications', async () => {
      try {
        if (!(await guardAuth())) return;
        const clearedAtLocal = new Date();
        const clearedAtServer = serverTimestamp ? serverTimestamp() : clearedAtLocal;
        await updateDoc(doc(db, 'users', user.id), { notificationsClearedAt: clearedAtServer });
        if (setUser) {
          setUser((prev) =>
            prev ? { ...prev, notificationsClearedAt: clearedAtLocal } : prev
          );
        }
        setData((prev) => {
          const users = Array.isArray(prev.users) ? prev.users : [];
          const nextUsers = users.map((u) =>
            u.id === user.id ? { ...u, notificationsClearedAt: clearedAtLocal } : u
          );
          return { ...prev, users: nextUsers };
        });
        addToast('Notificações limpas.', 'success');
      } catch (e) {
        addToast('Erro ao limpar notificações.', 'error');
      }
    });
  };

  const handleOpenNotification = async (n) => {
    if (!n) return;
    try {
      if (!(await guardAuth())) return;
      await updateDoc(doc(db, 'notifications', n.id), { read_by: arrayUnion(user.id) });
      setData((prev) => {
        const items = Array.isArray(prev.notifications) ? prev.notifications : [];
        const next = items.map((item) => {
          if (item.id !== n.id) return item;
          const readBy = Array.isArray(item.read_by) ? item.read_by : [];
          if (readBy.includes(user.id)) return item;
          return { ...item, read_by: [...readBy, user.id] };
        });
        return { ...prev, notifications: next };
      });
    } catch (e) {
      // noop
    }
    const target = resolveNotificationTarget(n);
    setView(target);
  };

  return { handleClearNotifications, handleOpenNotification };
};
