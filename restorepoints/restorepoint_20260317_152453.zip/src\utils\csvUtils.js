const CSV_TEMPLATE = [
  'uid,nome,tarefa,data,status',
  ',Nome Sobrenome,Microfone Volante,10/02/2026,Pendente',
  ',Nome Sobrenome,Pedestal,12/02/2026,Pendente'
].join('\n');

const splitCsvLine = (line, delimiter) => {
  const out = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      const next = line[i + 1];
      if (inQuotes && next === '"') {
        current += '"';
        i++;
        continue;
      }
      inQuotes = !inQuotes;
      continue;
    }
    if (ch === delimiter && !inQuotes) {
      out.push(current);
      current = '';
      continue;
    }
    current += ch;
  }
  out.push(current);
  return out;
};

const parseCsv = (text) => {
  const lines = String(text || '')
    .split(/\r?\n/)
    .filter((l) => l.trim() !== '');
  if (lines.length === 0) return { headers: [], rows: [] };
  const first = lines[0];
  const delimiter = first.includes(';') && !first.includes(',') ? ';' : ',';
  const headers = splitCsvLine(first, delimiter).map((h) =>
    h
      .trim()
      .toLowerCase()
      .replace(/^\uFEFF/, '')
  );
  const rows = lines.slice(1).map((line) => {
    const cells = splitCsvLine(line, delimiter);
    const row = {};
    headers.forEach((h, idx) => {
      row[h] = (cells[idx] || '').trim();
    });
    return row;
  });
  return { headers, rows };
};

const normalizeCsvDate = (value) => {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(raw)) {
    const [d, m, y] = raw.split('/');
    return `${y}-${m}-${d}`;
  }
  if (/^\d{2}-\d{2}-\d{4}$/.test(raw)) {
    const [d, m, y] = raw.split('-');
    return `${y}-${m}-${d}`;
  }
  if (/^\d{4}\/\d{2}\/\d{2}$/.test(raw)) {
    const [y, m, d] = raw.split('/');
    return `${y}-${m}-${d}`;
  }
  return '';
};

export { CSV_TEMPLATE, splitCsvLine, parseCsv, normalizeCsvDate };
