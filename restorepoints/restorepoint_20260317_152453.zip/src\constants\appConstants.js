﻿export const ADMIN_UIDS = ['Y93qpOE5dHUpvHvRMyNpAfo9wwQ2', 'ZfQXTFDszIgJCPxwm5nenkydrmL2'];

export const ASSIGNMENT_TYPES = [
  'Microfone Volante',
  'Pedestal',
  'Indicador Entrada',
  'Indicador Auditório',
  'Sistema de Áudio',
  'Sistema de Vídeo',
  'Leitor A Sentinela',
  'Leitor Estudo Bíblico',
  'Presidente Fim de Semana',
  'LANCHE_ORADOR'
];

export const STATUS_TYPES = ['pendente', 'confirmado', 'rejeitado', 'troca'];
