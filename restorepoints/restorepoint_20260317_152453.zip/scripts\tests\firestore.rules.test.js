﻿const fs = require('fs');
const {
  initializeTestEnvironment,
  assertFails
} = require('@firebase/rules-unit-testing');
const { doc, setDoc, getDoc } = require('firebase/firestore');

let testEnv;

describe('Firestore rules - chat disabled', function () {
  this.timeout(20000);

  before(async () => {
    const rules = fs.readFileSync('firestore.rules', 'utf8');
    testEnv = await initializeTestEnvironment({
      projectId: 'minhas-designacoes-app',
      firestore: { rules }
    });

    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      await setDoc(doc(db, 'users', 'alice'), { approved: true, isAdmin: false, email: 'alice@example.com' });
      await setDoc(doc(db, 'users', 'bob'), { approved: false, isAdmin: false, email: 'bob@example.com' });
    });
  });

  after(async () => {
    await testEnv.clearFirestore();
    await testEnv.cleanup();
  });

  it('approved user cannot create chat message', async () => {
    const aliceDb = testEnv.authenticatedContext({ uid: 'alice' }).firestore();
    await assertFails(
      setDoc(doc(aliceDb, 'chats/room1/messages/msg1'), {
        senderId: 'alice',
        text: 'oi',
        read: false,
        read_by: ['alice']
      })
    );
  });

  it('approved user cannot read chat message', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      await setDoc(doc(db, 'chats/room1/messages/msg2'), { senderId: 'alice', text: 'oi' });
    });
    const aliceDb = testEnv.authenticatedContext({ uid: 'alice' }).firestore();
    await assertFails(getDoc(doc(aliceDb, 'chats/room1/messages/msg2')));
  });

  it('approved user cannot write chats_meta', async () => {
    const aliceDb = testEnv.authenticatedContext({ uid: 'alice' }).firestore();
    await assertFails(setDoc(doc(aliceDb, 'chats_meta/room1'), { members: ['alice'] }));
  });
});
