const http = require('http');
const host = '127.0.0.1';
const port = 5173;
const timeoutMs = 20000;

console.log('Verificando servidor local já em execução...');

let resolved = false;
let output = '';

const finish = (code, message) => {
  if (resolved) return;
  resolved = true;
  if (message) console.log(message);
  process.exit(code);
};

const tryRequest = () => {
  http
    .get({ host, port, path: '/' }, (res) => {
      const ok = res.statusCode && res.statusCode >= 200 && res.statusCode < 400;
      finish(ok ? 0 : 1, `Localhost test status: ${res.statusCode}`);
    })
    .on('error', () => {
      // retry until timeout
    });
};

const startTime = Date.now();
const poll = setInterval(() => {
  if (resolved) return clearInterval(poll);
  if (Date.now() - startTime > timeoutMs) {
    clearInterval(poll);
    finish(1, 'Localhost test timeout. Vite server did not respond in time.');
  }
  tryRequest();
}, 1000);

// poll until timeout
