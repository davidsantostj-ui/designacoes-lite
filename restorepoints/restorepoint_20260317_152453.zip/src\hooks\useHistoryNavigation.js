import { useEffect, useRef } from 'react';

const INITIAL_STATE = { view: 'DASHBOARD' };

export const useHistoryNavigation = ({ user, view, setView }) => {
  const historyReadyRef = useRef(false);

  useEffect(() => {
    if (!user) return;
    if (!historyReadyRef.current) {
      window.history.replaceState(INITIAL_STATE, '');
      historyReadyRef.current = true;
      return;
    }
    window.history.pushState({ view }, '');
  }, [view, user]);

  useEffect(() => {
    if (!user) return;
    const handleBackButton = (event) => {
      if (view !== 'DASHBOARD') {
        event.preventDefault();
        setView('DASHBOARD');
      }
    };
    window.addEventListener('popstate', handleBackButton);
    return () => window.removeEventListener('popstate', handleBackButton);
  }, [user, view, setView]);
};
