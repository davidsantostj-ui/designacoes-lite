﻿import React, { useState } from 'react';
import { ThumbsDown, ThumbsUp } from 'lucide-react';
import UserAvatar from '../../components/UserAvatar';

const AdminApprovalsTab = ({ data, handleUpdateApproval, handleApproveAll, handleApproveByDomain }) => {
  const [domain, setDomain] = useState('');
  const pendingCount = (data?.users || []).filter((u) => !u.approved).length;

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-xs font-black uppercase text-slate-400 px-1">Novos Cadastros</h3>
        <div className="flex items-center gap-2">
          {pendingCount > 0 && handleApproveAll && (
            <button
              onClick={() => {
                if (confirm(`Aprovar todos os ${pendingCount} cadastros pendentes?`)) handleApproveAll();
              }}
              className="px-3 py-2 rounded-xl bg-emerald-50 text-emerald-600 text-[9px] font-black uppercase tracking-widest"
            >
              Aprovar todos
            </button>
          )}
          <div className="flex items-center gap-2">
            <input
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              placeholder="@dominio.com"
              className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-navy-900 text-xs"
            />
            <button
              onClick={() => {
                const d = (domain || '').trim().replace(/^@/, '').toLowerCase();
                if (!d) return alert('Informe um domínio (ex: @empresa.com)');
                const count = (data?.users || []).filter((u) => !u.approved && (u.email || '').toLowerCase().endsWith(d)).length;
                if (count === 0) return alert('Nenhum usuário encontrado para esse domínio.');
                if (confirm(`Aprovar ${count} usuários do domínio ${d}?`) && handleApproveByDomain) handleApproveByDomain(d);
              }}
              className="px-3 py-2 rounded-xl bg-blue-50 text-blue-600 text-[9px] font-black uppercase tracking-widest"
            >
              Aprovar domínio
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {data.users
          .filter((u) => !u.approved)
          .map((u) => (
            <div
              key={u.id}
              className="bg-white dark:bg-navy-800 card-surface p-4 rounded-3xl shadow-sm flex items-center justify-between border-2 border-amber-100 dark:border-navy-700 animate-slide-up"
            >
              <div className="flex items-center gap-3">
                <UserAvatar name={u.name} surname={u.surname} userId={u.id} size="sm" />
                <div>
                  <p className="font-bold text-sm dark:text-white">
                    {u.name} {u.surname}
                  </p>
                  <p className="text-[10px] text-slate-400 font-medium">{u.phone}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleUpdateApproval(u.id, false)}
                  className="touch-target w-10 h-10 bg-red-50 text-red-600 rounded-xl active:scale-90"
                >
                  <ThumbsDown size={18} />
                </button>
                <button
                  onClick={() => handleUpdateApproval(u.id, true)}
                  className="touch-target w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl active:scale-90"
                >
                  <ThumbsUp size={18} />
                </button>
              </div>
            </div>
          ))}
        {data.users.filter((u) => !u.approved).length === 0 && (
          <p className="text-center text-xs text-slate-400 py-10 font-black uppercase">
            Tudo aprovado!
          </p>
        )}
      </div>
    </div>
  );
};

export default AdminApprovalsTab;
