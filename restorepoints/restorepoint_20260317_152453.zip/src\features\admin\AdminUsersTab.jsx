﻿import React from 'react';
import { Copy, Download, Eye, MoreHorizontal, ShieldCheck, Trash2 } from 'lucide-react';
import UserAvatar from '../../components/UserAvatar';

const AdminUsersTab = ({
  data,
  user,
  isAdminUid,
  handleImpersonate,
  selectedAdminUser,
  setSelectedAdminUser,
  handleToggleAdminRole,
  handleDeleteUser,
  handleUpdateUserName
}) => {
  const approvedUsers = data.users.filter((u) => u.approved);

  const handleCopyUid = async (uid) => {
    try {
      await navigator.clipboard.writeText(uid);
    } catch (e) {
      const tmp = document.createElement('textarea');
      tmp.value = uid;
      tmp.setAttribute('readonly', 'true');
      tmp.style.position = 'absolute';
      tmp.style.left = '-9999px';
      document.body.appendChild(tmp);
      tmp.select();
      document.execCommand('copy');
      tmp.remove();
    }
  };

  const handleExportUids = () => {
    const header = 'nome,uid';
    const rows = approvedUsers.map((u) => {
      const fullName = `${u.name || ''} ${u.surname || ''}`.trim();
      const safeName = `"${fullName.replace(/"/g, '""')}"`;
      return `${safeName},${u.id}`;
    });
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'uids_usuarios.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-xs font-black uppercase text-slate-400 px-1">Gestão de Usuários</h3>
        <button
          onClick={handleExportUids}
          className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-navy-800 text-[9px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 flex items-center gap-2"
        >
          <Download size={12} /> Exportar UIDs
        </button>
      </div>
      <div className="space-y-2">
        {approvedUsers.map((u) => {
          const isUserAdmin = u.isAdmin || isAdminUid(u.id);
          return (
            <div
              key={u.id}
              className="bg-white dark:bg-navy-800 card-surface p-4 rounded-3xl shadow-sm flex flex-col gap-3 border dark:border-slate-800"
            >
              <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3 min-w-0">
                    <UserAvatar
                      name={u.name}
                      surname={u.surname}
                      userId={u.id}
                      size="sm"
                      lastActive={u.last_active}
                    />
                    <div className="min-w-0">
                      <p className="font-bold text-sm dark:text-white truncate">
                        {u.name} {u.surname}
                      </p>
                      {isUserAdmin && (
                        <span className="text-[8px] font-black uppercase text-emerald-600">
                          Admin
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {u.id !== user.id && !isAdminUid(u.id) && (
                      <button
                        onClick={() => handleImpersonate(u)}
                        className="touch-target w-9 h-9 bg-orange-50 text-orange-600 rounded-lg active:scale-90"
                      >
                        <Eye size={16} />
                      </button>
                    )}
                    <button
                      onClick={() => setSelectedAdminUser(selectedAdminUser === u.id ? null : u.id)}
                      className="touch-target w-9 h-9 bg-slate-50 dark:bg-navy-700 text-slate-400 rounded-lg active:scale-90"
                    >
                      <MoreHorizontal size={16} />
                    </button>
                  </div>
                </div>
                {selectedAdminUser === u.id && (
                  <div className="pt-3 border-t dark:border-slate-700 space-y-4 animate-slide-up">
                    <div className="bg-slate-50 dark:bg-navy-900 p-3 rounded-2xl flex flex-col gap-3">
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          if (!handleUpdateUserName) return;
                          const form = e.currentTarget;
                          const name = form.elements.name.value;
                          const surname = form.elements.surname.value;
                          handleUpdateUserName(u.id, name, surname);
                        }}
                        className="space-y-2"
                      >
                        <p className="text-[8px] font-black uppercase text-slate-400">
                          Nome no App
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <input
                            name="name"
                            defaultValue={u.name || ''}
                            placeholder="Nome"
                            className="w-full p-2 bg-white dark:bg-navy-800 rounded-xl text-xs font-bold"
                            required
                          />
                          <input
                            name="surname"
                            defaultValue={u.surname || ''}
                            placeholder="Sobrenome"
                            className="w-full p-2 bg-white dark:bg-navy-800 rounded-xl text-xs font-bold"
                          />
                        </div>
                        <button
                          type="submit"
                          className="w-full px-3 py-2 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center gap-2 text-[9px] font-black uppercase active:scale-95"
                        >
                          Salvar nome
                        </button>
                      </form>
                      <div>
                        <p className="text-[8px] font-black uppercase text-slate-400">E-MAIL</p>
                        <p className="text-xs font-black dark:text-blue-400">{u.email || '—'}</p>
                      </div>
                      <div>
                        <p className="text-[8px] font-black uppercase text-slate-400">UID</p>
                        <div className="mt-1 flex items-center gap-2">
                          <p className="text-[10px] font-black text-slate-600 dark:text-slate-300 break-all flex-1">
                            {u.id}
                          </p>
                          <button
                            onClick={() => handleCopyUid(u.id)}
                            className="px-2 py-1 rounded-lg bg-white dark:bg-navy-800 border dark:border-slate-700 text-[8px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-1"
                          >
                            <Copy size={10} /> Copiar
                          </button>
                        </div>
                      </div>
                      {!isAdminUid(u.id) && (
                        <button
                          onClick={() => handleToggleAdminRole(u)}
                          className="w-full px-3 py-2 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center gap-2 text-[9px] font-black uppercase active:scale-95"
                        >
                          <ShieldCheck size={12} /> {isUserAdmin ? 'Remover Admin' : 'Tornar Admin'}
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteUser(u.id)}
                        className="w-full px-3 py-2 bg-red-50 text-red-500 rounded-xl flex items-center justify-center gap-2 text-[9px] font-black uppercase active:scale-95"
                      >
                        <Trash2 size={12} /> Remover
                      </button>
                    </div>
                  </div>
                )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AdminUsersTab;
