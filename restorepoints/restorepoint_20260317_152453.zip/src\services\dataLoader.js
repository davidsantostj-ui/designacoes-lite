import {
  collection,
  getDocs,
  limit,
  orderBy,
  query,
  where
} from 'firebase/firestore';

export function buildDataLoader({
  db,
  withRetry,
  getDateDaysAgo,
  getMonthStartIso,
  isImpersonating,
  user,
  isRealAdminUser
}) {
  const inFlight = new Map();

  const runOnce = async (key, fn) => {
    if (inFlight.has(key)) return inFlight.get(key);
    const p = fn().finally(() => inFlight.delete(key));
    inFlight.set(key, p);
    return p;
  };

  const loadSections = async (sections = []) => {
    const updates = {};
    const ready = {};
    const wanted = new Set(sections);

    if (wanted.has('users')) {
      const snap = await runOnce('users', () =>
        isRealAdminUser
          ? withRetry(() => getDocs(collection(db, 'users')))
          : withRetry(() =>
              getDocs(query(collection(db, 'users'), where('approved', '==', true), limit(200)))
            )
      );
      updates.users = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      ready.users = true;
    }

    if (wanted.has('assignments')) {
      const cutoff = getMonthStartIso ? getMonthStartIso() : getDateDaysAgo(30);
      const snap = await runOnce('assignments', () =>
        withRetry(() =>
          getDocs(
            query(
              collection(db, 'assignments'),
              where('date', '>=', cutoff),
              orderBy('date', 'desc'),
              limit(200)
            )
          )
        )
      );
      updates.assignments = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      ready.assignments = true;
    }

    if (wanted.has('notifications')) {
      const snap = await runOnce('notifications', () =>
        withRetry(() =>
          getDocs(query(collection(db, 'notifications'), orderBy('created_at', 'desc'), limit(15)))
        )
      );
      updates.notifications = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      ready.notifications = true;
    }

    if (wanted.has('announcements')) {
      const snap = await runOnce('announcements', () =>
        withRetry(() =>
          getDocs(query(collection(db, 'announcements'), orderBy('created_at', 'desc'), limit(50)))
        )
      );
      const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      items.sort((a, b) => (b.pinned === true) - (a.pinned === true));
      updates.announcements = items;
      ready.announcements = true;
    }

    if (wanted.has('swapLogs')) {
      const snap = await runOnce('swapLogs', () =>
        withRetry(() =>
          getDocs(query(collection(db, 'swap_logs'), orderBy('createdAt', 'desc'), limit(200)))
        )
      );
      updates.swapLogs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      ready.swapLogs = true;
    }

    return { updates, ready };
  };

  return { loadSections };
}
