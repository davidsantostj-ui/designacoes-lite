import { useState } from 'react';

export const useAdminTabs = (initialTab = 'DESIGNACOES') => {
  const [adminTab, setAdminTab] = useState(initialTab);
  return { adminTab, setAdminTab };
};
