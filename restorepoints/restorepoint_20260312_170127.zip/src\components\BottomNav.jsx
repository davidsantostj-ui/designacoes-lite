import {
  Home,
  Calendar as CalIcon,
  Repeat,
  Megaphone
} from 'lucide-react';

const BottomNav = ({ view, onNavigate, unreadAnnouncementsCount }) => (
  <nav className="fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-navy-900/95 glass border-t dark:border-slate-800 flex items-center gap-1 p-2 pb-[max(12px,env(safe-area-inset-bottom))] z-[220] shadow-2xl">
    {[
      { id: 'DASHBOARD', icon: Home, label: 'Início' },
      { id: 'ASSIGNMENTS_MONTH', icon: CalIcon, label: 'Agenda' },
      { id: 'SWAP_MARKET', icon: Repeat, label: 'Mural' },
      { id: 'ANNOUNCEMENTS', icon: Megaphone, label: 'Anúncios' }
    ].map((item) => (
      <button
        key={item.id}
        onClick={() => onNavigate(item.id)}
        className={`flex flex-1 min-w-0 flex-col items-center justify-center px-1 py-1.5 rounded-2xl transition-all relative ${view === item.id ? 'text-navy-900 dark:text-blue-400' : 'text-slate-400'}`}
      >
        <item.icon
          size={20}
          className={`mb-1 transition-transform ${view === item.id ? 'scale-110' : ''}`}
          strokeWidth={view === item.id ? 2.5 : 2}
        />
        <span className="text-[8px] font-black uppercase tracking-widest">{item.label}</span>
        {item.id === 'ANNOUNCEMENTS' && unreadAnnouncementsCount > 0 && (
          <div className="absolute top-1 right-3 w-2 h-2 bg-red-500 rounded-full border border-white"></div>
        )}
        {view === item.id && (
          <div className="absolute top-1 w-1 h-1 bg-navy-900 dark:bg-blue-400 rounded-full"></div>
        )}
      </button>
    ))}
  </nav>
);

export default BottomNav;
