import { useCallback, useMemo, useState } from 'react';
import { buildDataLoader } from '../services/dataLoader';

export const useAppDataLoader = ({
  initialData,
  initialReady,
  db,
  withRetry,
  getDateDaysAgo,
  isImpersonating,
  user,
  isRealAdminUser,
  authReady,
  guardAuth,
  addToast
}) => {
  const [data, setData] = useState(initialData);
  const [dataReady, setDataReady] = useState(initialReady);

  const dataLoader = useMemo(
    () =>
      buildDataLoader({
        db,
        withRetry,
        getDateDaysAgo,
        isImpersonating,
        user,
        isRealAdminUser
      }),
    [db, withRetry, getDateDaysAgo, isImpersonating, user, isRealAdminUser]
  );

  const loadSections = useCallback(
    async (sections, opts = {}) => {
      if (!(await guardAuth())) return false;
      try {
        const { updates, ready } = await dataLoader.loadSections(sections || []);
        if (Object.keys(updates).length > 0) {
          setData((prev) => ({ ...prev, ...updates }));
        }
        if (Object.keys(ready).length > 0) {
          setDataReady((prev) => ({ ...prev, ...ready }));
        }
        if (!opts.silent && opts.toast) addToast(opts.toast, 'success');
        return true;
      } catch (e) {
        if (!opts.silent && opts.toastError) addToast(opts.toastError, 'error');
        return false;
      }
    },
    [guardAuth, addToast, dataLoader]
  );

  const handleRefreshData = useCallback(
    async (opts = {}) => {
      const sections = opts.sections || [
        'users',
        'assignments',
        'notifications',
        'announcements',
        'swapLogs'
      ];
      await loadSections(sections, {
        silent: opts.silent,
        toast: 'Dados atualizados.',
        toastError: 'Erro ao atualizar dados.'
      });
    },
    [loadSections]
  );

  const safeLoadSections = useCallback(
    async (sections, opts = {}) => {
      if (!user || !authReady) return false;
      try {
        return await loadSections(sections, opts);
      } catch (e) {
        console.error('loadSections failed', e);
        return false;
      }
    },
    [user, authReady, loadSections]
  );

  const loadForView = useCallback(
    (nextView) => {
      if (!user || !authReady) return;
      if (nextView === 'DASHBOARD') {
        safeLoadSections(['assignments', 'notifications', 'announcements'], {
          silent: true
        });
      } else if (nextView === 'ASSIGNMENTS_MONTH') {
        safeLoadSections(['assignments', 'swapLogs'], { silent: true });
      } else if (nextView === 'SWAP_MARKET') {
        safeLoadSections(['assignments', 'swapLogs', 'users'], { silent: true });
      } else if (nextView === 'ANNOUNCEMENTS') {
        safeLoadSections(['announcements'], { silent: true });
      } else if (nextView === 'ALERTS') {
        safeLoadSections(['notifications', 'announcements'], { silent: true });
      } else if (nextView === 'NOTIFICATIONS_LIST') {
        safeLoadSections(['notifications', 'users'], { silent: true });
      } else if (nextView === 'SEARCH') {
        safeLoadSections(['users'], { silent: true });
      }
    },
    [user, authReady, safeLoadSections]
  );

  return {
    data,
    setData,
    dataReady,
    setDataReady,
    loadSections,
    handleRefreshData,
    safeLoadSections,
    loadForView
  };
};
