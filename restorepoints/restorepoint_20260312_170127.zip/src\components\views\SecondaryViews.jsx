import React from 'react';
import AssignmentsMonth from '../../features/assignments/AssignmentsMonth';
import SwapMarket from '../../features/assignments/SwapMarket';

const SecondaryViews = ({
  view,
  data,
  dataReady,
  user,
  getFriendlyTime,
  renderSkeletonList,
  formatDatePt,
  formatAssignmentLabel,
  isPastDate,
  handleAccept,
  handleSwapRequest,
  handleCancelSwap,
  downloadIcs,
  openSwapLogId,
  setOpenSwapLogId,
  swapLogsByAssignment,
  getUserDisplayName,
  handleAcceptSwap
}) => {
  if (!['ASSIGNMENTS_MONTH', 'SWAP_MARKET'].includes(view)) return null;

  return (
    <div className="p-5 space-y-6 max-w-lg sm:max-w-xl lg:max-w-3xl mx-auto w-full animate-fade-in">
      {view === 'ASSIGNMENTS_MONTH' && (
        <AssignmentsMonth
          data={data}
          dataReady={dataReady}
          user={user}
          renderSkeletonList={renderSkeletonList}
          formatDatePt={formatDatePt}
          formatAssignmentLabel={formatAssignmentLabel}
          isPastDate={isPastDate}
          handleAccept={handleAccept}
          handleSwapRequest={handleSwapRequest}
          handleCancelSwap={handleCancelSwap}
          downloadIcs={downloadIcs}
          openSwapLogId={openSwapLogId}
          setOpenSwapLogId={setOpenSwapLogId}
          swapLogsByAssignment={swapLogsByAssignment}
          getUserDisplayName={getUserDisplayName}
          getFriendlyTime={getFriendlyTime}
        />
      )}

      {view === 'SWAP_MARKET' && (
        <SwapMarket
          data={data}
          user={user}
          formatDatePt={formatDatePt}
          formatAssignmentLabel={formatAssignmentLabel}
          isPastDate={isPastDate}
          handleAcceptSwap={handleAcceptSwap}
          getUserDisplayName={getUserDisplayName}
        />
      )}
    </div>
  );
};

export default SecondaryViews;
