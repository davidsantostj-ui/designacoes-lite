﻿import React from 'react';
import { Utensils } from 'lucide-react';

const SwapMarket = ({
  data,
  user,
  formatDatePt,
  formatAssignmentLabel,
  isPastDate,
  handleAcceptSwap,
  getUserDisplayName
}) => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-black px-1 uppercase tracking-tighter">Mural de Trocas</h2>
      {data.assignments
        .filter((a) => a.status === 'troca')
        .map((a) => {
          const swapUser = data.users.find((u) => u.id === a.usuario_id);
          const swapName = getUserDisplayName(swapUser) || 'Usuário';
          const isOwner = a.usuario_id === user.id;
          const canAccept = !isOwner && !isPastDate(a.date);
          return (
            <div
              key={a.id}
              className="bg-white dark:bg-navy-800 p-5 rounded-4xl border border-orange-100 dark:border-navy-700 flex flex-col gap-4 shadow-sm animate-slide-up"
            >
              <div className="flex justify-between items-start">
                <div className="min-w-0">
                  <span className="text-[9px] font-black text-orange-500 uppercase tracking-widest">
                    {formatDatePt(a.date)}
                  </span>
                  <div className="flex items-center gap-2 mt-1">
                    {a.tipo_designacao === 'LANCHE_ORADOR' && (
                      <Utensils size={14} className="text-amber-500" />
                    )}
                    <h4 className="font-black text-sm truncate dark:text-white leading-tight">
                      {formatAssignmentLabel(a.tipo_designacao)}
                    </h4>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 font-bold uppercase">
                    {swapName} precisa de troca
                  </p>
                </div>
              </div>
              <button
                onClick={() => canAccept && handleAcceptSwap(a.id)}
                disabled={!canAccept}
                className={`w-full font-black py-3 rounded-2xl text-[10px] uppercase tracking-widest shadow-md transition-all ${canAccept ? 'bg-navy-900 text-white active:scale-95' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}
              >
                {isOwner
                  ? 'SUA TROCA'
                  : isPastDate(a.date)
                    ? 'DATA EXPIRADA'
                    : 'ACEITAR ESTA DESIGNAÇÃO'}
              </button>
            </div>
          );
        })}
      {data.assignments.filter((a) => a.status === 'troca').length === 0 && (
        <p className="text-center text-xs text-slate-400 py-20 font-bold uppercase tracking-widest">
          Nenhuma troca no mural.
        </p>
      )}
    </div>
  );
};

export default SwapMarket;
