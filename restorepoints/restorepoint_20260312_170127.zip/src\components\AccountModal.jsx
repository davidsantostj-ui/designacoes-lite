import React from 'react';
import { X } from 'lucide-react';

const AccountModal = ({
  open,
  user,
  displayName,
  onClose,
  onChangePassword,
  onChangeDisplayName,
  onUpdatePreferences,
  soundEnabled,
  toggleSoundNotifications,
  dndEnabled,
  setDndEnabled,
  dndFrom,
  setDndFrom,
  dndTo,
  setDndTo
}) => {
  if (!open) return null;
  if (!user) return null;

  return (
    <div
      className="fixed inset-0 z-[120] bg-black/30 flex items-start justify-center p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md max-h-[85vh] overflow-y-auto no-scrollbar p-6 space-y-6 animate-fade-in bg-white dark:bg-navy-900 rounded-4xl shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black uppercase tracking-widest">Conta</h3>
          <button
            onClick={onClose}
            className="touch-target w-8 h-8 rounded-full bg-slate-100 dark:bg-navy-800 flex items-center justify-center"
          >
            <X size={14} />
          </button>
        </div>
        <section className="bg-slate-50 dark:bg-navy-950/40 p-4 rounded-3xl space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-black uppercase tracking-widest text-slate-700 dark:text-slate-200">
                Alterar senha
              </p>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                Segurança da conta
              </p>
            </div>
          </div>
          <form onSubmit={onChangePassword} className="space-y-3">
            <input
              name="current"
              type="password"
              placeholder="Senha atual"
              className="w-full p-4 bg-white dark:bg-navy-800 rounded-2xl text-center text-lg font-bold"
              required
            />
            <input
              name="n1"
              type="password"
              placeholder="Nova senha"
              className="w-full p-4 bg-white dark:bg-navy-800 rounded-2xl text-center text-lg font-bold"
              required
            />
            <input
              name="n2"
              type="password"
              placeholder="Repetir senha"
              className="w-full p-4 bg-white dark:bg-navy-800 rounded-2xl text-center text-lg font-bold"
              required
            />
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 font-black text-xs uppercase text-slate-400"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-3 bg-navy-900 text-white font-black text-xs uppercase rounded-xl"
              >
                Salvar
              </button>
            </div>
          </form>
        </section>
        <section className="bg-slate-50 dark:bg-navy-950/40 p-4 rounded-3xl space-y-3">
          <div>
            <p className="text-sm font-black uppercase tracking-widest text-slate-700 dark:text-slate-200">
              Alterar nome
            </p>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
              Exibido no app
            </p>
          </div>
          <form onSubmit={onChangeDisplayName} className="space-y-3">
            <input
              name="fullName"
              placeholder="Nome e sobrenome"
              defaultValue={displayName}
              className="w-full p-4 bg-white dark:bg-navy-800 rounded-2xl text-center text-sm font-bold"
              required
            />
            <button
              type="submit"
              className="w-full py-3 bg-emerald-600 text-white font-black text-xs uppercase rounded-xl"
            >
              Salvar Nome
            </button>
          </form>
        </section>
        <section className="bg-slate-50 dark:bg-navy-950/40 p-4 rounded-3xl space-y-3">
          <div>
            <p className="text-sm font-black uppercase tracking-widest text-slate-700 dark:text-slate-200">
              Preferências
            </p>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
              Sons e horários
            </p>
          </div>
          <div className="flex items-center justify-between bg-white dark:bg-navy-800 p-4 rounded-2xl">
            <div>
              <p className="text-xs font-bold">Aviso sonoro</p>
              <p className="text-[9px] text-slate-400 font-semibold">
                Notificações internas do app
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only peer"
                checked={soundEnabled}
                onChange={toggleSoundNotifications}
              />
              <div className="w-10 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:bg-emerald-500 transition-colors"></div>
              <div className="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform peer-checked:translate-x-4"></div>
            </label>
          </div>
          <div className="bg-white dark:bg-navy-800 p-4 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold">Não perturbe</p>
                <p className="text-[9px] text-slate-400 font-semibold">
                  Silencia sons por horário
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only peer"
                  checked={dndEnabled}
                  onChange={() => setDndEnabled(!dndEnabled)}
                />
                <div className="w-10 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:bg-emerald-500 transition-colors"></div>
                <div className="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform peer-checked:translate-x-4"></div>
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <p className="text-[9px] font-black uppercase text-slate-400 mb-1">Das</p>
                <input
                  type="time"
                  value={dndFrom}
                  onChange={(e) => setDndFrom(e.target.value)}
                  className="w-full p-2 rounded-xl bg-slate-50 dark:bg-navy-900 text-xs font-bold"
                />
              </div>
              <div>
                <p className="text-[9px] font-black uppercase text-slate-400 mb-1">Até</p>
                <input
                  type="time"
                  value={dndTo}
                  onChange={(e) => setDndTo(e.target.value)}
                  className="w-full p-2 rounded-xl bg-slate-50 dark:bg-navy-900 text-xs font-bold"
                />
              </div>
            </div>
          </div>
        </section>
        <section className="bg-slate-50 dark:bg-navy-950/40 p-4 rounded-3xl space-y-3">
          <div>
            <p className="text-sm font-black uppercase tracking-widest text-slate-700 dark:text-slate-200">
              Conta e privacidade
            </p>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
              Idioma, disponibilidade e telefone
            </p>
          </div>
          <form onSubmit={onUpdatePreferences} className="space-y-3">
            <div>
              <p className="text-[9px] font-black uppercase text-slate-400 mb-1">Idioma</p>
              <select
                name="language"
                defaultValue={user.preferredLanguage || 'pt-BR'}
                className="w-full p-3 bg-white dark:bg-navy-800 rounded-2xl text-sm border dark:border-slate-700"
              >
                <option value="pt-BR">Português (Brasil)</option>
                <option value="en-US">English (US)</option>
              </select>
            </div>
            <label className="flex items-center justify-between bg-white dark:bg-navy-800 p-4 rounded-2xl">
              <div>
                <p className="text-xs font-bold">Ocultar telefone</p>
                <p className="text-[9px] text-slate-400 font-semibold">
                  Esconde seu número no app
                </p>
              </div>
              <input type="checkbox" name="hidePhone" defaultChecked={!!user.hidePhone} />
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <p className="text-[9px] font-black uppercase text-slate-400 mb-1">
                  Disponível das
                </p>
                <input
                  type="time"
                  name="availFrom"
                  defaultValue={user.availabilityFrom || '08:00'}
                  className="w-full p-2 rounded-xl bg-white dark:bg-navy-800 text-xs font-bold"
                />
              </div>
              <div>
                <p className="text-[9px] font-black uppercase text-slate-400 mb-1">Até</p>
                <input
                  type="time"
                  name="availTo"
                  defaultValue={user.availabilityTo || '20:00'}
                  className="w-full p-2 rounded-xl bg-white dark:bg-navy-800 text-xs font-bold"
                />
              </div>
            </div>
            <textarea
              name="availNote"
              defaultValue={user.availabilityNote || ''}
              placeholder="Observações de disponibilidade (opcional)"
              className="w-full p-3 bg-white dark:bg-navy-800 rounded-2xl text-sm border dark:border-slate-700 min-h-[80px]"
            />
            <button
              type="submit"
              className="w-full py-3 bg-navy-900 text-white font-black text-xs uppercase rounded-xl"
            >
              Salvar Preferências
            </button>
          </form>
        </section>
      </div>
    </div>
  );
};

export default AccountModal;
